import os
import re
from pathlib import Path

import cv2
import numpy as np
import torch


def env_flag(name, default=False):
    value = os.environ.get(name, "")
    if value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_float(name, default):
    value = os.environ.get(name, "")
    if value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def env_int(name, default):
    value = os.environ.get(name, "")
    if value == "":
        return default
    try:
        return int(value)
    except ValueError:
        return default


def safe_name(value, default="seq"):
    value = str(value or default)
    value = value.replace("\\", "/").split("/")[-1]
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", value)
    return value or default


def colormap_id(name):
    name = str(name or "turbo").strip().lower()
    mapping = {
        "jet": cv2.COLORMAP_JET,
        "turbo": getattr(cv2, "COLORMAP_TURBO", cv2.COLORMAP_JET),
        "inferno": cv2.COLORMAP_INFERNO,
        "magma": cv2.COLORMAP_MAGMA,
        "viridis": cv2.COLORMAP_VIRIDIS,
        "plasma": cv2.COLORMAP_PLASMA,
        "hot": cv2.COLORMAP_HOT,
    }
    return mapping.get(name, getattr(cv2, "COLORMAP_TURBO", cv2.COLORMAP_JET))


def normalize_score_map(score_map, output_size, blur=0, gamma=1.0, percentile=100.0):
    if isinstance(score_map, torch.Tensor):
        score = score_map.detach().float().cpu()
        score = score.squeeze()
        score = score.numpy()
    else:
        score = np.asarray(score_map, dtype=np.float32).squeeze()
    if score.ndim != 2:
        score = score.reshape(int(np.sqrt(score.size)), -1)
    score = cv2.resize(score, (output_size, output_size), interpolation=cv2.INTER_CUBIC)
    score = score.astype(np.float32)
    if percentile and percentile < 100.0:
        hi = float(np.nanpercentile(score, percentile))
        if np.isfinite(hi):
            score = np.minimum(score, hi)
    min_v = float(np.nanmin(score))
    max_v = float(np.nanmax(score))
    if not np.isfinite(min_v) or not np.isfinite(max_v) or max_v <= min_v:
        score = np.zeros_like(score, dtype=np.uint8)
    else:
        score = ((score - min_v) / (max_v - min_v)).clip(0, 1)
        if gamma > 0 and gamma != 1.0:
            score = np.power(score, gamma)
        score = (score * 255.0).clip(0, 255).astype(np.uint8)
    if blur and blur > 1:
        blur = int(blur)
        if blur % 2 == 0:
            blur += 1
        score = cv2.GaussianBlur(score, (blur, blur), 0)
    return score


def score_map_to_heatmap(score_map, output_size, blur=0, gamma=1.0, percentile=100.0, colormap="turbo"):
    score = normalize_score_map(score_map, output_size, blur=blur, gamma=gamma, percentile=percentile)
    return cv2.applyColorMap(score, colormap_id(colormap)), score


def overlay_search_heatmap_on_frame(
    image_rgb,
    score_map,
    prev_state,
    resize_factor,
    search_size,
    alpha,
    blur=0,
    gamma=1.0,
    percentile=100.0,
    colormap="turbo",
    threshold=0.0,
    soft_alpha=True,
    visible_percentile=0.0,
    alpha_power=1.0,
):
    image_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    h_img, w_img = image_bgr.shape[:2]
    heat_search, score_search = score_map_to_heatmap(
        score_map,
        int(search_size),
        blur=blur,
        gamma=gamma,
        percentile=percentile,
        colormap=colormap,
    )

    cx_prev = float(prev_state[0]) + 0.5 * float(prev_state[2])
    cy_prev = float(prev_state[1]) + 0.5 * float(prev_state[3])
    crop_side = float(search_size) / float(resize_factor)
    crop_x1 = cx_prev - 0.5 * crop_side
    crop_y1 = cy_prev - 0.5 * crop_side

    x1 = int(np.floor(crop_x1))
    y1 = int(np.floor(crop_y1))
    x2 = int(np.ceil(crop_x1 + crop_side))
    y2 = int(np.ceil(crop_y1 + crop_side))
    crop_w = max(1, x2 - x1)
    crop_h = max(1, y2 - y1)
    heat_crop = cv2.resize(heat_search, (crop_w, crop_h), interpolation=cv2.INTER_CUBIC)
    score_crop = cv2.resize(score_search, (crop_w, crop_h), interpolation=cv2.INTER_CUBIC).astype(np.float32) / 255.0

    ix1 = max(0, x1)
    iy1 = max(0, y1)
    ix2 = min(w_img, x2)
    iy2 = min(h_img, y2)
    if ix2 <= ix1 or iy2 <= iy1:
        return image_bgr

    hx1 = ix1 - x1
    hy1 = iy1 - y1
    hx2 = hx1 + (ix2 - ix1)
    hy2 = hy1 + (iy2 - iy1)
    roi = image_bgr[iy1:iy2, ix1:ix2]
    heat_roi = heat_crop[hy1:hy2, hx1:hx2]
    score_roi = score_crop[hy1:hy2, hx1:hx2]
    if visible_percentile and visible_percentile > 0:
        cutoff = float(np.nanpercentile(score_roi, visible_percentile))
        if np.isfinite(cutoff):
            score_roi = np.where(score_roi >= cutoff, score_roi, 0.0)
    if threshold > 0:
        score_roi = np.clip((score_roi - threshold) / max(1e-6, 1.0 - threshold), 0.0, 1.0)
    if alpha_power and alpha_power > 0 and alpha_power != 1.0:
        score_roi = np.power(score_roi, alpha_power)
    if soft_alpha:
        alpha_map = (alpha * score_roi)[..., None]
    else:
        alpha_map = (alpha * (score_roi > 0))[..., None]
    blended = roi.astype(np.float32) * (1.0 - alpha_map) + heat_roi.astype(np.float32) * alpha_map
    image_bgr[iy1:iy2, ix1:ix2] = blended.clip(0, 255).astype(np.uint8)
    return image_bgr


def draw_box(image_bgr, box, color=(0, 0, 255), thickness=2):
    x, y, w, h = [float(v) for v in box[:4]]
    if w <= 0 or h <= 0:
        return
    h_img, w_img = image_bgr.shape[:2]
    x1 = max(0, min(w_img - 1, int(round(x))))
    y1 = max(0, min(h_img - 1, int(round(y))))
    x2 = max(0, min(w_img - 1, int(round(x + w))))
    y2 = max(0, min(h_img - 1, int(round(y + h))))
    if x2 > x1 and y2 > y1:
        cv2.rectangle(image_bgr, (x1, y1), (x2, y2), color, thickness)


def resize_max_side(image_bgr, max_side):
    if max_side <= 0:
        return image_bgr
    h, w = image_bgr.shape[:2]
    side = max(h, w)
    if side <= max_side:
        return image_bgr
    ratio = float(max_side) / float(side)
    return cv2.resize(image_bgr, None, fx=ratio, fy=ratio, interpolation=cv2.INTER_AREA)


class ScoreMapVisConfig:
    def __init__(self, prefix):
        self.enable = env_flag(f"{prefix}_SCORE_MAP_VIS", False)
        self.output_dir = os.environ.get(f"{prefix}_SCORE_MAP_DIR", "output/score_map_vis")
        self.alpha = env_float(f"{prefix}_SCORE_MAP_ALPHA", 0.45)
        self.draw_box = env_flag(f"{prefix}_SCORE_MAP_DRAW_BOX", True)
        self.max_side = env_int(f"{prefix}_SCORE_MAP_MAX_SIDE", 0)
        self.jpg_quality = env_int(f"{prefix}_SCORE_MAP_JPG_QUALITY", 90)
        self.stride = max(1, env_int(f"{prefix}_SCORE_MAP_STRIDE", 1))
        self.blur = env_int(f"{prefix}_SCORE_MAP_BLUR", 0)
        self.gamma = env_float(f"{prefix}_SCORE_MAP_GAMMA", 1.0)
        self.percentile = env_float(f"{prefix}_SCORE_MAP_PERCENTILE", 100.0)
        self.colormap = os.environ.get(f"{prefix}_SCORE_MAP_COLORMAP", "turbo")
        self.threshold = env_float(f"{prefix}_SCORE_MAP_THRESHOLD", 0.18)
        self.soft_alpha = env_flag(f"{prefix}_SCORE_MAP_SOFT_ALPHA", True)
        self.visible_percentile = env_float(f"{prefix}_SCORE_MAP_VISIBLE_PERCENTILE", 0.0)
        self.alpha_power = env_float(f"{prefix}_SCORE_MAP_ALPHA_POWER", 1.0)


def save_score_map_vis(cfg, image, score_map, prev_state, pred_state, resize_factor, search_size, info, frame_id):
    if cfg is None or not cfg.enable:
        return
    if frame_id % cfg.stride != 0:
        return
    seq_name = safe_name((info or {}).get("path", "seq"))
    frame_num = (info or {}).get("num", frame_id)
    try:
        frame_num = int(frame_num)
    except Exception:
        frame_num = int(frame_id)

    vis = overlay_search_heatmap_on_frame(
        image_rgb=image,
        score_map=score_map,
        prev_state=prev_state,
        resize_factor=resize_factor,
        search_size=search_size,
        alpha=cfg.alpha,
        blur=cfg.blur,
        gamma=cfg.gamma,
        percentile=cfg.percentile,
        colormap=cfg.colormap,
        threshold=cfg.threshold,
        soft_alpha=cfg.soft_alpha,
        visible_percentile=cfg.visible_percentile,
        alpha_power=cfg.alpha_power,
    )
    if cfg.draw_box:
        draw_box(vis, pred_state, color=(0, 0, 255), thickness=2)
    vis = resize_max_side(vis, cfg.max_side)

    out_dir = Path(cfg.output_dir) / seq_name
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{frame_num:05d}.jpg"
    cv2.imwrite(str(out_path), vis, [int(cv2.IMWRITE_JPEG_QUALITY), int(cfg.jpg_quality)])

import os
import torch
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from modelscope import snapshot_download
from sam3.model_builder import build_sam3_image_model
from sam3.model.sam3_image_processor import Sam3Processor

class SAM3ImagePredictor:
    def __init__(self, cache_dir='./weights', device='cuda'):
        self.device = device
        print("正在检查/下载 SAM 3 模型 (源: ModelScope)...")
        try:
            download_dir = snapshot_download('facebook/sam3', cache_dir=cache_dir)
            ckpt_path = os.path.join(download_dir, "sam3.pt")
        except Exception as e:
            print(f"ModelScope 下载失败，尝试直接查找: {e}")
            ckpt_path = os.path.join(cache_dir, "sam3.pt")
            
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"未找到模型权重: {ckpt_path}")

        print(f"加载模型: {ckpt_path}")
        self.model = build_sam3_image_model(checkpoint_path=ckpt_path)
        self.processor = Sam3Processor(self.model, device=device)
        self.inference_state = None
        self.image_size = (0, 0) # Global (W, H)

    def set_image(self, image_input):
        """
        设置图片 (用于全图推理模式)
        """
        if isinstance(image_input, str):
            image = Image.open(image_input).convert("RGB")
        elif isinstance(image_input, np.ndarray):
            image = Image.fromarray(image_input)
        elif isinstance(image_input, Image.Image):
            image = image_input
        else:
            raise ValueError("不支持的图片格式")

        self.image_size = image.size 
        self.inference_state = self.processor.set_image(image)
        return self.inference_state

    # =============================================================
    # 【核心新增】基于搜索区域的推理方法
    # =============================================================
    def predict_with_crop(self, image_input, text_prompt, tracker_box, search_factor=2.0, conf_thresh=0.45, neg_points=None, use_box_prompt=False):
        """
        基于跟踪框裁剪搜索区域进行推理 (推荐用于跟踪任务)
        
        Args:
            image_input: 原始大图 (RGB)，可以是 path/ndarray/PIL.Image
            text_prompt: 文本提示
            tracker_box: [x, y, w, h] 跟踪器预测框 (绝对像素坐标)
            search_factor: 搜索区域相对于目标框的扩大倍数 (默认 2.0 倍)
            conf_thresh: 置信度阈值
            neg_points: 全局坐标下的负样本点 list of [x, y]
            use_box_prompt: 是否将 tracker_box 作为提示输入给模型。
                            False (推荐): 不给 Box，只给一个位于 Crop 中心的正样本点，依靠 Text + Center Point 找目标。
                            True: 给 Box 提示，强约束，容易被不准的框误导。
        
        Returns:
            dict: 包含还原回全图坐标的 masks, boxes, scores
        """
        # 1. 准备原始图片
        if isinstance(image_input, np.ndarray):
            full_image = Image.fromarray(image_input)
        elif isinstance(image_input, Image.Image):
            full_image = image_input
        else:
            full_image = Image.open(image_input).convert("RGB")
            
        W_global, H_global = full_image.size
        
        # 2. 计算裁剪区域 (Search Region)
        tx, ty, tw, th = tracker_box
        cx, cy = tx + tw/2, ty + th/2
        
        # 扩大搜索区域
        crop_size = max(tw, th) * search_factor
        
        x1 = int(cx - crop_size / 2)
        y1 = int(cy - crop_size / 2)
        x2 = int(cx + crop_size / 2)
        y2 = int(cy + crop_size / 2)
        
        # 处理边界 (Clip)
        crop_x1 = max(0, x1)
        crop_y1 = max(0, y1)
        crop_x2 = min(W_global, x2)
        crop_y2 = min(H_global, y2)
        
        # 实际裁剪
        crop_img = full_image.crop((crop_x1, crop_y1, crop_x2, crop_y2))
        W_crop, H_crop = crop_img.size
        
        # 3. 构造提示 (Prompt Engineering)
        local_box = None
        local_pos_points = None
        
        if use_box_prompt:
            # 策略：强约束 (Box Prompt)
            # 映射 Box 到局部坐标：[x, y, w, h]
            local_box = [
                tx - crop_x1, 
                ty - crop_y1, 
                tw, 
                th
            ]
        else:
            # 策略：弱约束 (Center Point Prompt) - 推荐
            # 不给 Box，只给一个位于 Crop 中心的正样本点
            # 告诉 SAM 3："目标就在这张图中间，它是 text_prompt 描述的东西，你自己找边界"
            center_x = W_crop / 2
            center_y = H_crop / 2
            local_pos_points = [[center_x, center_y]]

        # Points 映射 (全局负样本点 -> 局部)
        local_neg_points = []
        if neg_points:
            for p in neg_points:
                px, py = p
                # 只有在 Crop 范围内的负样本点才保留
                if crop_x1 <= px < crop_x2 and crop_y1 <= py < crop_y2:
                    local_neg_points.append([px - crop_x1, py - crop_y1])

        # 4. 在 Crop 上运行 SAM 3 (推理)
        # 临时设置 image_size 为 Crop 尺寸，以适配 predict 内部的归一化逻辑
        self.image_size = (W_crop, H_crop)
        self.inference_state = self.processor.set_image(crop_img)
        
        # 调用基础 predict (复用已有逻辑)
        results_local = self.predict(
            text_prompt=text_prompt,
            box=local_box,               # 如果 use_box_prompt=False，这里是 None
            pos_points=local_pos_points, # 如果 use_box_prompt=False，这里有中心点
            neg_points=local_neg_points, # 局部坐标下的负样本点
            conf_thresh=conf_thresh
        )
        
        # 5. 坐标还原: 局部 -> 全局 (Crop -> Global)
        # 还原 Masks
        masks_local = results_local['masks'] # (N, H_crop, W_crop)
        masks_global_list = []
        
        for mask in masks_local:
            # 创建全图大小的空白 Mask
            mask_global = np.zeros((H_global, W_global), dtype=bool)
            # 将局部 Mask 贴回去
            mask_np = mask.cpu().numpy() if isinstance(mask, torch.Tensor) else mask
            
            if mask_np.ndim == 3: mask_np = mask_np[0]
            
            # 将局部 mask 填入全局 mask 的对应位置
            # 使用 H_crop 和 W_crop 确保尺寸对应 (防止因为 Clip 导致的尺寸不一致)
            mask_global[crop_y1:crop_y1+H_crop, crop_x1:crop_x1+W_crop] = mask_np
            masks_global_list.append(torch.from_numpy(mask_global))
            
        if len(masks_global_list) > 0:
            masks_global = torch.stack(masks_global_list)
        else:
            masks_global = torch.zeros((0, H_global, W_global), dtype=torch.bool)

        # 还原 Boxes (xyxy 格式)
        boxes_local = results_local['boxes'] # (N, 4) xyxy format
        boxes_global_list = []
        for box in boxes_local:
            bx1, by1, bx2, by2 = box
            boxes_global_list.append([
                bx1 + crop_x1,
                by1 + crop_y1,
                bx2 + crop_x1,
                by2 + crop_y1
            ])
        boxes_global = torch.tensor(boxes_global_list, device=self.device) if boxes_global_list else torch.tensor([])

        # 6. 恢复 image_size 状态为全图尺寸 (保持状态一致性)
        self.image_size = (W_global, H_global)

        return {
            "masks": masks_global,
            "boxes": boxes_global, # xyxy format
            "scores": results_local['scores']
        }

    # =============================================================
    # 基础推理方法 (无需改动，被 predict_with_crop 调用)
    # =============================================================
    def predict(self, text_prompt, box=None, neg_points=None, pos_points=None, conf_thresh=0.45):
        if self.inference_state is None:
            raise RuntimeError("请先调用 set_image() 或 predict_with_crop()")

        self.processor.set_confidence_threshold(conf_thresh, self.inference_state)
        self.processor.reset_all_prompts(self.inference_state)

        output = self.processor.set_text_prompt(
            state=self.inference_state,
            prompt=text_prompt
        )

        if box is not None:
            # 这里的 box 已经是局部坐标了 (如果在 crop 模式下)
            W, H = self.image_size 
            x, y, w, h = box
            norm_box = [(x + w/2) / W, (y + h/2) / H, w / W, h / H]
            output = self.processor.add_geometric_prompt(
                box=norm_box, label=True, state=self.inference_state
            )

        # 处理点提示
        points_list, labels_list = [], []
        if pos_points:
            for p in pos_points: points_list.append(p); labels_list.append(1)
        if neg_points:
            for p in neg_points: points_list.append(p); labels_list.append(0)

        if points_list:
            self._add_points_manually(points_list, labels_list)
            output = self.processor._forward_grounding(self.inference_state)

        return {"masks": output["masks"], "boxes": output["boxes"], "scores": output["scores"]}

    def _add_points_manually(self, points, labels):
        W, H = self.image_size
        norm_points = [[p[0] / W, p[1] / H] for p in points]
        
        # 【修正】确保维度正确 (N, 1, 2)
        points_tensor = torch.tensor(norm_points, device=self.device, dtype=torch.float32).unsqueeze(1)
        labels_tensor = torch.tensor(labels, device=self.device, dtype=torch.long).unsqueeze(1)
        
        geo_prompt = self.inference_state.get("geometric_prompt")
        if geo_prompt:
            geo_prompt.append_points(points_tensor, labels_tensor)

# ------------------------------------------------------------------
# 可视化函数 (保持之前增强版)
# ------------------------------------------------------------------
def plot_results(image_pil, result, text_prompt, tracker_box=None, neg_points=None, pos_points=None, output_path=None):
    """
    绘制预测结果，包括输入的跟踪框、正/负样本点
    
    Args:
        image_pil: 原始图片
        result: predict 返回的字典
        text_prompt: 文本提示
        tracker_box: [x, y, w, h] 输入的跟踪框
        neg_points: list of [x, y] 负样本点
        pos_points: list of [x, y] 正样本点
        output_path: 保存路径
    """
    plt.figure(figsize=(10, 10))
    plt.imshow(image_pil)
    ax = plt.gca()
    
    # ------------------------------------------
    # 1. 绘制输入的辅助信息 (Prompt Inputs)
    # ------------------------------------------
    
    # A. 绘制输入的跟踪器框 (红色虚线)
    if tracker_box is not None:
        x0, y0, w, h = tracker_box
        ax.add_patch(plt.Rectangle((x0, y0), w, h, 
                                   edgecolor='red', facecolor='none', lw=2, linestyle='--'))
        ax.text(x0, y0 - 8, "Tracker Input", fontsize=10, color='red', weight='bold', 
                bbox={'facecolor': 'white', 'alpha': 0.5, 'pad': 1, 'edgecolor': 'none'})

    # B. 绘制输入的负样本点 (红色 X - "不要这里")
    if neg_points is not None and len(neg_points) > 0:
        # 拆分坐标以便批量绘制
        neg_x = [p[0] for p in neg_points]
        neg_y = [p[1] for p in neg_points]
        ax.scatter(neg_x, neg_y, color='red', marker='x', s=120, linewidth=3, label='Neg Point')

    # C. 绘制输入的正样本点 (黄色星号 - "要这里")
    if pos_points is not None and len(pos_points) > 0:
        pos_x = [p[0] for p in pos_points]
        pos_y = [p[1] for p in pos_points]
        # 使用黄色填充、黑色边框的星号，保证在亮/暗背景都清晰可见
        ax.scatter(pos_x, pos_y, color='yellow', marker='*', s=180, linewidth=1.5, edgecolors='black', label='Pos Point')

    # ------------------------------------------
    # 2. 绘制 SAM 3 的输出结果 (Output Mask & Box)
    # ------------------------------------------
    masks = result["masks"]
    boxes = result["boxes"]
    scores = result["scores"]
    
    for i in range(len(masks)):
        # 过滤低分结果 (可根据需要调整显示阈值)
        if scores[i] < 0.2: continue 
        
        # --- 绘制 Mask ---
        mask_np = masks[i].cpu().numpy()
        if mask_np.ndim == 3: mask_np = mask_np[0]
        
        # 使用半透明颜色叠加
        # 随机颜色 (偏绿色/青色系，代表模型预测)
        color = np.concatenate([np.random.random(3) * 0.5 + 0.2, np.array([0.5])], axis=0)
        h_img, w_img = mask_np.shape[-2:]
        mask_image = mask_np.reshape(h_img, w_img, 1) * color.reshape(1, 1, -1)
        ax.imshow(mask_image)
        
        # --- 绘制 Box (SAM 3 Output) ---
        # 绿色实线，表示最终确定的位置
        box_np = boxes[i].cpu().numpy() # xyxy format
        x0, y0, x1, y1 = box_np
        w, h = x1 - x0, y1 - y0
        
        ax.add_patch(plt.Rectangle((x0, y0), w, h, edgecolor='#00FF00', facecolor='none', lw=2))
        
        # 标签
        label_text = f"SAM3: {scores[i]:.2f}"
        ax.text(x0, y0, label_text, fontsize=12, color='black', weight='bold',
                bbox={'facecolor': '#00FF00', 'alpha': 0.8, 'pad': 2, 'edgecolor': 'none'})

    # 添加图例 (如果在角落没遮挡的话)
    # ax.legend(loc='upper right') 
    
    plt.axis('off')
    if output_path:
        plt.savefig(output_path, bbox_inches='tight', dpi=300)
        print(f"可视化结果已保存: {output_path}")
    
    # 只有在非 headless 环境才 show，防止报错
    # plt.show() 
    plt.close()

import random

def generate_background_points(image_size, tracker_box, num_points=8, expand_ratio=1.5):
    """
    在 tracker_box 外围生成随机负样本点 (背景点)
    
    Args:
        image_size: (W, H) 图片尺寸
        tracker_box: [x, y, w, h] 目标框 (绝对坐标)
        num_points: 生成点的数量 (建议 4-8 个)
        expand_ratio: 采样范围相对于目标框的倍数 (建议 1.5 - 2.0)
                      注意：这个范围最好小于 predict_with_crop 的 search_factor，
                      确保这些点能落在 Crop 出来的图里，否则会被过滤掉。
    Returns:
        points: list of [x, y]
    """
    W, H = image_size
    x, y, w, h = tracker_box
    
    # 1. 定义目标区域 (Inner Box - 禁区)
    x1_in, y1_in = x, y
    x2_in, y2_in = x + w, y + h
    
    # 2. 定义采样区域 (Outer Box - 也就是 Search Region 的一部分)
    cx, cy = x + w/2, y + h/2
    w_out = w * expand_ratio
    h_out = h * expand_ratio
    
    x1_out = max(0, int(cx - w_out / 2))
    y1_out = max(0, int(cy - h_out / 2))
    x2_out = min(W, int(cx + w_out / 2))
    y2_out = min(H, int(cy + h_out / 2))
    
    neg_points = []
    max_attempts = num_points * 20 # 防止死循环
    count = 0
    
    while len(neg_points) < num_points and count < max_attempts:
        count += 1
        # 在 Outer Box 内随机撒点
        rx = random.randint(x1_out, x2_out)
        ry = random.randint(y1_out, y2_out)
        
        # 3. 拒绝采样：如果点落在了目标框 (Inner Box) 内，丢弃
        # 也可以加一个 margin，让点离目标框边缘保持一点距离
        if not (x1_in <= rx <= x2_in and y1_in <= ry <= y2_in):
            neg_points.append([rx, ry])
            
    return neg_points
# ==========================================
# 主程序调用示例
# ==========================================
if __name__ == "__main__":
    predictor = SAM3ImagePredictor(cache_dir='/media/amax/xiao_20T1/code/jly/weights')
    
    image_path = "./assets/images/test_image.jpg"
    raw_image = Image.open(image_path).convert("RGB")
    W, H = raw_image.size
    # 假设跟踪器当前预测的位置
    tracker_pred_box = [100, 300,200, 250] # [x, y, w, h] 绝对坐标
    
    bg_points = generate_background_points(
        image_size=(W, H),
        tracker_box=tracker_pred_box,
        num_points=4,       # 撒 8 个点
        expand_ratio=2.0    # 范围控制
    )
    print(f"生成的背景负样本点: {bg_points}")
    # 【关键调用】：使用 predict_with_crop
    # search_factor=2.0 意味着在目标周围截取 2 倍大小的区域喂给 SAM 3
    results = predictor.predict_with_crop(
        image_input=raw_image,
        text_prompt="window",
        tracker_box=tracker_pred_box,
        search_factor=4.0,  # 越大越容易找回目标，但分辨率会降低
        conf_thresh=0.5,
        neg_points=bg_points,
        use_box_prompt=False,
    )
    
    # 这里的 results 已经自动映射回全图坐标了，直接画在原图上即可
    plot_results(
        raw_image, 
        results, 
        "window", 
        tracker_box=tracker_pred_box,
        neg_points=bg_points,        # 你的背景负样本点
        # pos_points=global_pos_points, # 你的中心正样本点
        output_path="./sam3_crop_result.jpg"
    )
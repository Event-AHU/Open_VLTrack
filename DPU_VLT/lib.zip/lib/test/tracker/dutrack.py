import math
import bisect
import json
import numpy as np
from lib.models.dutrack import build_dutrack
from lib.test.tracker.basetracker import BaseTracker
import torch

from lib.test.tracker.vis_utils import gen_visualization
from lib.test.utils.hann import hann2d
from lib.train.data.processing_utils import sample_target
# for debug
import cv2
import os

from lib.test.tracker.data_utils import Preprocessor
from lib.utils.box_ops import clip_box
from lib.utils.ce_utils import generate_mask_cond
from lib.models.dutrack.i2d import descriptgenRefiner
from tracking.draw_heatmap import visualize_attn
from lib.test.tracker.score_map_vis import ScoreMapVisConfig, save_score_map_vis


class DUTrack(BaseTracker):
    def __init__(self, params):
        super(DUTrack, self).__init__(params)
        network = build_dutrack(params.cfg, training=False)
        network.load_state_dict(torch.load(self.params.checkpoint,weights_only=False, map_location='cpu')['net'], strict=False)
        self.cfg = params.cfg
        self.network = network.cuda()
        self.network.eval()
        self.preprocessor = Preprocessor()
        self.state = None

        self.feat_sz = self.cfg.TEST.SEARCH_SIZE // self.cfg.MODEL.BACKBONE.STRIDE
        # motion constrain
        self.output_window = hann2d(torch.tensor([self.feat_sz, self.feat_sz]).long(), centered=True).cuda()

        # for debug
        self.debug = params.debug
        self.use_visdom = params.debug
        self.frame_id = 0
        if self.debug:
            if not self.use_visdom:
                self.save_dir = "debug"
                if not os.path.exists(self.save_dir):
                    os.makedirs(self.save_dir)
            # else:
            #     # self.add_hook()
            #     self._init_visdom(None, 1)
        # for save boxes from all queries
        self.save_all_boxes = params.save_all_boxes
        self.z_dict1 = {}
        self.descriptgenRefiner = descriptgenRefiner(params.cfg.MODEL.BACKBONE.BLIP_DIR,params.cfg.MODEL.BACKBONE.BERT_DIR)
        self.test_parsed_text_cache = self._load_test_parsed_text_cache()
        self.test_text_cache = self._load_test_text_cache()
        self.test_cache_stats = {'calls': 0, 'used': 0, 'fallback_no_seq': 0, 'fallback_no_prev': 0, 'fallback_gap': 0}
        self.score_map_vis_cfg = ScoreMapVisConfig("DUTRACK")

    def _load_test_parsed_text_cache(self):
        cfg = self._text_cfg()
        parsed_path = str(getattr(cfg, 'PARSED_TEXT_PATH', '')).strip() if cfg is not None else ''
        if not parsed_path:
            return {}
        try:
            with open(parsed_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f'[WARN] Failed to load test parsed text cache {parsed_path}: {e}')
            return {}
        if not isinstance(data, dict):
            print(f'[WARN] Invalid test parsed text cache format: {parsed_path}')
            return {}
        print(f'[INFO] Loaded test parsed text cache from {parsed_path} ({len(data)} entries)')
        return data

    def _load_test_text_cache(self):
        cfg = self._text_cfg()
        if cfg is None or not bool(getattr(cfg, 'CACHE_ENABLE', False)):
            return {}
        cache_path = str(getattr(cfg, 'CACHE_PATH', '')).strip()
        if not cache_path:
            print('[WARN] TEST.TEXT.CACHE_ENABLE is true but CACHE_PATH is empty.')
            return {}
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f'[WARN] Failed to load test text cache {cache_path}: {e}')
            return {}
        entries = data.get('entries', {}) if isinstance(data, dict) else {}
        if not isinstance(entries, dict):
            print(f'[WARN] Invalid test text cache format: {cache_path}')
            return {}
        by_seq = {}
        for key, item in entries.items():
            if not isinstance(item, dict):
                continue
            seq_name = str(item.get('seq_name', '')).strip() or (key.rsplit(':', 1)[0] if isinstance(key, str) and ':' in key else '')
            if not seq_name:
                continue
            frame_id = item.get('frame_id', None)
            if frame_id is None and isinstance(key, str) and ':' in key:
                try:
                    frame_id = int(key.rsplit(':', 1)[1])
                except Exception:
                    continue
            try:
                frame_id = int(frame_id)
            except Exception:
                continue
            by_seq.setdefault(seq_name, []).append((
                frame_id,
                {
                    'target': str(item.get('qwen_target', item.get('target', ''))).strip(),
                    'concepts': str(item.get('qwen_concept', '')).strip(),
                    'background': str(item.get('qwen_background', '')).strip(),
                }
            ))
        for seq_name in by_seq:
            by_seq[seq_name].sort(key=lambda x: x[0])
        total = sum(len(v) for v in by_seq.values())
        print(f'[INFO] Loaded test text cache from {cache_path} ({len(by_seq)} seqs, {total} entries)')
        return by_seq

    def _build_structured_text(self, raw_text, target='', concepts='', background=''):
        return {
            'raw': str(raw_text or ''),
            'target': str(target or ''),
            'concepts': str(concepts or ''),
            'background': str(background or ''),
        }

    def _parse_sequence_text(self, seq_text, seq_name=None):
        if seq_name is not None:
            parsed = self.test_parsed_text_cache.get(str(seq_name), None)
            if isinstance(parsed, dict):
                return self._build_structured_text(
                    parsed.get('raw', seq_text),
                    parsed.get('target', ''),
                    " ".join(str(x) for x in parsed.get('concepts', [])) if isinstance(parsed.get('concepts', []), list) else parsed.get('concepts', ''),
                    " ".join(str(x) for x in parsed.get('background', [])) if isinstance(parsed.get('background', []), list) else parsed.get('background', ''),
                )
        if isinstance(seq_text, dict):
            return self._build_structured_text(
                seq_text.get('raw', ''),
                seq_text.get('target', ''),
                seq_text.get('concepts', ''),
                seq_text.get('background', ''),
            )
        raw = str(seq_text or '').strip()
        parts = [p.strip() for p in raw.split('[SEP]')] if '[SEP]' in raw else []
        if len(parts) >= 3:
            target, concepts, background = parts[0], parts[1], parts[2]
        else:
            target, concepts, background = '', '', ''
        return self._build_structured_text(raw, target=target, concepts=concepts, background=background)

    def _resolve_test_cache_text(self, info):
        cfg = self._text_cfg()
        if cfg is None or not bool(getattr(cfg, 'CACHE_ENABLE', False)):
            return None
        seq_name = info.get('path', None) if info is not None else None
        frame_num = info.get('num', None) if info is not None else None
        if seq_name is None or frame_num is None:
            return None

        stats = self.test_cache_stats
        stats['calls'] += 1
        seq_entries = self.test_text_cache.get(str(seq_name), None)
        if not seq_entries:
            stats['fallback_no_seq'] += 1
            return None

        frame_ids = [it[0] for it in seq_entries]
        pos = bisect.bisect_right(frame_ids, int(frame_num)) - 1
        if pos < 0:
            stats['fallback_no_prev'] += 1
            return None

        anchor_frame, refined = seq_entries[pos]
        max_gap = int(getattr(cfg, 'CACHE_MAX_GAP', 50))
        if max_gap >= 0 and (int(frame_num) - int(anchor_frame)) > max_gap:
            stats['fallback_gap'] += 1
            return None

        base = self._parse_sequence_text(getattr(self, 'sequence_text_description', None), seq_name=seq_name)
        if refined.get('target', '') and not base.get('target', ''):
            base['target'] = refined['target']
            if not base.get('raw', ''):
                base['raw'] = refined['target']
        if refined.get('concepts', ''):
            base['concepts'] = refined['concepts']
        if refined.get('background', ''):
            base['background'] = refined['background']
        stats['used'] += 1
        if bool(getattr(cfg, 'CACHE_DEBUG', False)):
            print(f"[TEST-QWEN] seq={seq_name} frame={frame_num} anchor={anchor_frame} concept={base['concepts']!r} background={base['background']!r}")
        return base

    def _text_cfg(self):
        return getattr(getattr(self.cfg, 'TEST', None), 'TEXT', None)

    def _class_prompt(self, object_class):
        if object_class is None:
            return ""
        cfg = self._text_cfg()
        template = getattr(cfg, 'CLASS_TEMPLATE', "a photo of {}") if cfg is not None else "a photo of {}"
        try:
            return template.format(object_class)
        except Exception:
            return f"a photo of {object_class}"

    def _resolve_description(self, image, info: dict):
        cfg = self._text_cfg()
        source = str(getattr(cfg, 'SOURCE', 'auto')).lower() if cfg is not None else 'auto'
        object_class = info.get('class', None) if info is not None else None

        # GT language (usually sequence-level) is provided at init frame only for lang datasets.
        gt_text = getattr(self, 'sequence_text_description', None)
        cache_text = self._resolve_test_cache_text(info if info is not None else {})
        if cache_text is not None:
            gt_text = cache_text
        if (gt_text is None or gt_text == "") and info is not None:
            gt_text = info.get('text_description', None)
        if (gt_text is None or gt_text == "") and info is not None:
            gt_text = info.get('init_text_description', None)

        if source == 'empty':
            return ""
        if source == 'gt':
            return gt_text or ""
        if source == 'class':
            return self._class_prompt(object_class)
        if source == 'blip':
            return self.descriptgenRefiner(image, cls=object_class)

        # auto: prefer GT text if available, otherwise fall back to BLIP caption.
        if gt_text is not None and gt_text != "":
            return gt_text
        return self.descriptgenRefiner(image, cls=object_class)

    def _should_update_description(self):
        cfg = self._text_cfg()
        policy = str(getattr(cfg, 'UPDATE_POLICY', 'on_update_key')).lower() if cfg is not None else 'on_update_key'
        if policy == 'never':
            return False
        if policy == 'always':
            return True
        return bool(getattr(self, 'updata_key', False))

    def initialize(self, image, info: dict):
        # forward the template once
        z_patch_arr, resize_factor, z_amask_arr = sample_target(image, info['init_bbox'], self.params.template_factor,
                                                    output_sz=self.params.template_size)

        # cache sequence-level language (if any) and resolve current description
        self.sequence_text_description = info.get('text_description', None)
        if self.sequence_text_description is None or self.sequence_text_description == "":
            self.sequence_text_description = info.get('init_text_description', None)
        self.descript = self._resolve_description(image, info)
        self.his_state = info['init_bbox']
        self.updata_key = False

        self.z_patch_arr = z_patch_arr
        template = self.preprocessor.process(z_patch_arr, z_amask_arr)
        with torch.no_grad():
            # self.z_dict1 = template
            self.memory_frames = [template.tensors]

        self.memory_masks = []
        if self.cfg.MODEL.BACKBONE.CE_LOC:  # use CE module
            template_bbox = self.transform_bbox_to_crop(info['init_bbox'], resize_factor,
                                                        template.tensors.device).squeeze(1)
            self.memory_masks.append(generate_mask_cond(self.cfg, 1, template.tensors.device, template_bbox))
        
        # save states
        # self.H,self.W,_ = image.shape
        self.state = info['init_bbox']
        self.frame_id = 0
        if self.save_all_boxes:
            '''save all predicted boxes'''
            all_boxes_save = info['init_bbox'] * self.cfg.MODEL.NUM_OBJECT_QUERIES
            return {"all_boxes": all_boxes_save}

    def ifupdata(self, his, cur, h, w):
        x1,y1,w1,h1 = his
        x2,y2,w2,h2 = cur
        stride = 1/32

        s1,s2 = w1*h1,w2*h2
        distance = math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
        if s1>s2:
            i = s2/s1
        else:
            i = s1/s2
        # if i < 0.95 :
        #     return True
        # if distance > stride*h or distance > stride*w :
        #     return True
        return True

    def track(self, image, info: dict = None):
        H, W, _ = image.shape
        self.frame_id += 1
        prev_state_for_vis = list(self.state)
        x_patch_arr, resize_factor, x_amask_arr = sample_target(image, self.state, self.params.search_factor,
                                                                output_sz=self.params.search_size)  # (x1, y1, w, h)
        search = self.preprocessor.process(x_patch_arr, x_amask_arr)
        if self._should_update_description():
            self.descript = self._resolve_description(image, info if info is not None else {})
            self.his_state = self.state

        # print(info['num'])
        # print(self.descript)
        # --------- select memory frames ---------
        box_mask_z = None
        if self.frame_id <= self.cfg.TEST.TEMPLATE_NUMBER:
            template_list = self.memory_frames.copy()
            if self.cfg.MODEL.BACKBONE.CE_LOC:  # use CE module
                box_mask_z = torch.cat(self.memory_masks, dim=1)
        else:
            template_list, box_mask_z = self.select_memory_frames()
        # --------- select memory frames ---------

        with torch.no_grad():
            # Provide the current predicted box (in crop coordinates) to enable CAC at test-time.
            search_bbox = self.transform_bbox_to_crop(
                self.state, resize_factor, search.tensors.device, crop_type='search'
            ).view(1, 4)
            out_dict = self.network.forward(
                template=template_list,
                search=[search.tensors],
                descript=[[self.descript]],
                search_anno=[search_bbox],
            )

        if isinstance(out_dict, list):
            out_dict = out_dict[-1]

        # A = visualize_attn(out_dict['attn'],x_patch_arr,info['path'],info['num'])
            
        # add hann windows
        pred_score_map = out_dict['score_map']
        response = self.output_window * pred_score_map
        pred_boxes = self.network.box_head.cal_bbox(response, out_dict['size_map'], out_dict['offset_map'])
        pred_boxes = pred_boxes.view(-1, 4)
        # Baseline: Take the mean of all pred boxes as the final result
        pred_box = (pred_boxes.mean(dim=0) * self.params.search_size / resize_factor).tolist()  # (cx, cy, w, h) [0,1]
        # get the final box result
        self.state = clip_box(self.map_box_back(pred_box, resize_factor), H, W, margin=10)
        save_score_map_vis(
            self.score_map_vis_cfg,
            image=image,
            score_map=response,
            prev_state=prev_state_for_vis,
            pred_state=self.state,
            resize_factor=resize_factor,
            search_size=self.params.search_size,
            info=info if info is not None else {},
            frame_id=self.frame_id,
        )

        self.updata_key = self.ifupdata(self.his_state,self.state,H,W)






        # --------- save memory frames and masks ---------
        z_patch_arr, z_resize_factor, z_amask_arr = sample_target(image, self.state, self.params.template_factor,
                                                    output_sz=self.params.template_size)
        cur_frame = self.preprocessor.process(z_patch_arr, z_amask_arr)
        frame = cur_frame.tensors
        # mask = cur_frame.mask
        if self.frame_id > self.cfg.TEST.MEMORY_THRESHOLD:
            frame = frame.detach().cpu()
            # mask = mask.detach().cpu()
        self.memory_frames.append(frame)
        if self.cfg.MODEL.BACKBONE.CE_LOC:  # use CE module
            template_bbox = self.transform_bbox_to_crop(self.state, z_resize_factor, frame.device).squeeze(1)
            self.memory_masks.append(generate_mask_cond(self.cfg, 1, frame.device, template_bbox))
        if 'pred_iou' in out_dict.keys():      # use IoU Head
            pred_iou = out_dict['pred_iou'].squeeze(-1)
            self.memory_ious.append(pred_iou)
        # --------- save memory frames and masks ---------
        
        # for debug
        # if self.debug:
        #     if not self.use_visdom:
        #         x1, y1, w, h = self.state
        #         image_BGR = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        #         cv2.rectangle(image_BGR, (int(x1),int(y1)), (int(x1+w),int(y1+h)), color=(0,0,255), thickness=2)
        #         save_path = os.path.join(self.save_dir, "%04d.jpg" % self.frame_id)
        #         cv2.imwrite(save_path, image_BGR)
        #     else:
        #         self.visdom.register((image, info['gt_bbox'].tolist(), self.state), 'Tracking', 1, 'Tracking')
        #
        #         self.visdom.register(torch.from_numpy(x_patch_arr).permute(2, 0, 1), 'image', 1, 'search_region')
        #         self.visdom.register(torch.from_numpy(self.z_patch_arr).permute(2, 0, 1), 'image', 1, 'template')
        #         self.visdom.register(pred_score_map.view(self.feat_sz, self.feat_sz), 'heatmap', 1, 'score_map')
        #         self.visdom.register((pred_score_map * self.output_window).view(self.feat_sz, self.feat_sz), 'heatmap', 1, 'score_map_hann')
        #
        #         if 'removed_indexes_s' in out_dict and out_dict['removed_indexes_s']:
        #             removed_indexes_s = out_dict['removed_indexes_s']
        #             removed_indexes_s = [removed_indexes_s_i.cpu().numpy() for removed_indexes_s_i in removed_indexes_s]
        #             masked_search = gen_visualization(x_patch_arr, removed_indexes_s)
        #             self.visdom.register(torch.from_numpy(masked_search).permute(2, 0, 1), 'image', 1, 'masked_search')
        #
        #         while self.pause_mode:
        #             if self.step:
        #                 self.step = False
        #                 break

        if self.save_all_boxes:
            '''save all predictions'''
            all_boxes = self.map_box_back_batch(pred_boxes * self.params.search_size / resize_factor, resize_factor)
            all_boxes_save = all_boxes.view(-1).tolist()  # (4N, )
            return {"target_bbox": self.state,
                    "all_boxes": all_boxes_save}
        else:
            return {"target_bbox": self.state}

    def select_memory_frames(self):
        num_segments = self.cfg.TEST.TEMPLATE_NUMBER
        cur_frame_idx = self.frame_id
        if num_segments != 1:
            assert cur_frame_idx > num_segments
            dur = cur_frame_idx // num_segments
            indexes = np.concatenate([
                np.array([0]),
                np.array(list(range(num_segments))) * dur + dur // 2
            ])
        else:
            indexes = np.array([0])
        indexes = np.unique(indexes)

        select_frames, select_masks = [], []
        
        for idx in indexes:
            frames = self.memory_frames[idx]
            if not frames.is_cuda:
                frames = frames.cuda()
            select_frames.append(frames)
            
            if self.cfg.MODEL.BACKBONE.CE_LOC:
                box_mask_z = self.memory_masks[idx]
                select_masks.append(box_mask_z.cuda())
        
        if self.cfg.MODEL.BACKBONE.CE_LOC:
            return select_frames, torch.cat(select_masks, dim=1)
        else:
            return select_frames, None
    
    def map_box_back(self, pred_box: list, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return [cx_real - 0.5 * w, cy_real - 0.5 * h, w, h]

    def map_box_back_batch(self, pred_box: torch.Tensor, resize_factor: float):
        cx_prev, cy_prev = self.state[0] + 0.5 * self.state[2], self.state[1] + 0.5 * self.state[3]
        cx, cy, w, h = pred_box.unbind(-1) # (N,4) --> (N,)
        half_side = 0.5 * self.params.search_size / resize_factor
        cx_real = cx + (cx_prev - half_side)
        cy_real = cy + (cy_prev - half_side)
        return torch.stack([cx_real - 0.5 * w, cy_real - 0.5 * h, w, h], dim=-1)

    def add_hook(self):
        conv_features, enc_attn_weights, dec_attn_weights = [], [], []

        for i in range(12):
            self.network.backbone.blocks[i].attn.register_forward_hook(
                # lambda self, input, output: enc_attn_weights.append(output[1])
                lambda self, input, output: enc_attn_weights.append(output[1])
            )

        self.enc_attn_weights = enc_attn_weights

def get_tracker_class():
    return DUTrack

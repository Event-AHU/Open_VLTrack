import os
import numpy as np
from lib.test.evaluation.data import Sequence, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text, load_str
from lib.utils.string_utils import clean_string
from lib.test.evaluation.otbdataset import OTBDataset


class OTB_LangDataset(BaseDataset):
    """OTB99-Lang evaluation dataset supporting test/train/all splits."""

    def __init__(self, split='test'):
        super().__init__()
        self.base_path = self.env_settings.otb_lang_path
        self.img_path = os.path.join(self.base_path, 'OTB_videos')
        self.split = split
        self.split_to_query_dir = {
            'train': 'OTB_query_train',
            'test': 'OTB_query_test',
        }
        self.otb_sequence_info = {item['name']: item for item in OTBDataset()._get_sequence_info_list()}
        self.sequence_info_list = self._get_sequence_info_list(split)

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_info_list])

    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        nz = sequence_info['nz']
        ext = sequence_info['ext']
        start_frame = sequence_info['startFrame']
        end_frame = sequence_info['endFrame']

        init_omit = 0
        if 'initOmit' in sequence_info:
            init_omit = sequence_info['initOmit']

        frames = [
            '{base_path}/{sequence_path}/{frame:0{nz}}.{ext}'.format(
                base_path=self.img_path,
                sequence_path=sequence_path,
                frame=frame_num,
                nz=nz,
                ext=ext,
            )
            for frame_num in range(start_frame + init_omit, end_frame + 1)
        ]

        anno_path = '{}/{}'.format(self.img_path, sequence_info['anno_path'])
        with open(anno_path, 'r') as _f:
            _first = _f.readline()
        _delim = ',' if ',' in _first else None
        ground_truth_rect = load_text(str(anno_path), delimiter=(_delim, None), dtype=np.float64, backend='numpy')

        query_dir = self.split_to_query_dir[sequence_info['lang_split']]
        text_dsp_path = os.path.join(self.base_path, query_dir, f"{sequence_info['name']}.txt")
        text_dsp = clean_string(load_str(text_dsp_path))

        return Sequence(
            sequence_info['name'],
            frames,
            f'otb_lang_{self.split}',
            ground_truth_rect[init_omit:, :],
            text_description=text_dsp,
            object_class=sequence_info['object_class'],
        )

    def __len__(self):
        return len(self.sequence_info_list)

    def _list_query_names(self, split):
        query_dir = os.path.join(self.base_path, self.split_to_query_dir[split])
        if not os.path.isdir(query_dir):
            raise FileNotFoundError(f'OTB-Lang query dir not found: {query_dir}')
        names = []
        for name in sorted(os.listdir(query_dir)):
            if not name.endswith('.txt'):
                continue
            names.append(os.path.splitext(name)[0])
        return names

    def _normalize_sequence_key(self, seq_name):
        alias_map = {
            'Human4': 'Human4_2',
            'Skating2-1': 'Skating2_1',
            'Skating2-2': 'Skating2_2',
            'Jogging-1': 'Jogging_1',
            'Jogging-2': 'Jogging_2',
        }
        return alias_map.get(seq_name, seq_name)

    def _build_sequence_info(self, seq_name, lang_split):
        lookup_name = self._normalize_sequence_key(seq_name)
        base_info = self.otb_sequence_info.get(lookup_name, None)
        if base_info is None:
            raise KeyError(f'OTB sequence metadata not found for language query "{seq_name}" (lookup "{lookup_name}")')
        info = dict(base_info)
        info['name'] = seq_name
        info['lang_split'] = lang_split
        self._adapt_to_local_layout(info, seq_name)
        return info

    def _get_sequence_info_list(self, split):
        splits = ['train', 'test'] if split == 'all' else [split]
        sequence_info_list = []
        for lang_split in splits:
            for seq_name in self._list_query_names(lang_split):
                sequence_info_list.append(self._build_sequence_info(seq_name, lang_split))
        return sequence_info_list

    def _adapt_to_local_layout(self, info, seq_name):
        """Prefer the actual folder/files in the local OTB99-Lang layout.

        Some local copies split multi-target sequences into directories such as
        `Skating2-1` and `Jogging-1`, instead of the original OTB `Skating2`
        / `Jogging` folder plus `.1/.2` annotations.
        """
        seq_root = os.path.join(self.img_path, seq_name)
        img_root = os.path.join(seq_root, 'img')
        gt_txt = os.path.join(seq_root, 'groundtruth_rect.txt')
        if os.path.isdir(img_root) and os.path.isfile(gt_txt):
            info['path'] = f'{seq_name}/img'
            info['anno_path'] = f'{seq_name}/groundtruth_rect.txt'
            return

        # Fallback: some local splits still keep split folder names but only
        # provide .1/.2 annotations inside them.
        if os.path.isdir(img_root):
            for cand in ['groundtruth_rect.1.txt', 'groundtruth_rect.2.txt', 'groundtruth_rect.txt']:
                cand_path = os.path.join(seq_root, cand)
                if os.path.isfile(cand_path):
                    info['path'] = f'{seq_name}/img'
                    info['anno_path'] = f'{seq_name}/{cand}'
                    return

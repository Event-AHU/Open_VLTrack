from easydict import EasyDict as edict
import yaml

"""
Add default config for OSTrack.
"""
cfg = edict()

# MODEL
cfg.MODEL = edict()
cfg.MODEL.PRETRAIN_FILE = "mae_pretrain_vit_base.pth"
cfg.MODEL.EXTRA_MERGER = False

cfg.MODEL.RETURN_INTER = False
cfg.MODEL.RETURN_STAGES = []

# MODEL.CAC (Counterfactual Attention Correction)
cfg.MODEL.CAC = edict()
# 总开关
cfg.MODEL.CAC.ENABLE = False
# 仅在最后融合阶段最后N层做bias操作
cfg.MODEL.CAC.APPLY_LAST_N = 0  # only apply CAC in the last N fusion blocks
# CAC 生效层位策略
cfg.MODEL.CAC.LAYER_POLICY = 'last'  # last | first
# CAC 生效层数（优先于 APPLY_LAST_N）
cfg.MODEL.CAC.APPLY_N = 0
cfg.MODEL.CAC.LAYER_INDICES = []  # explicit 1-based main-block indices, e.g. [12] or [24]
# bias强度系数
cfg.MODEL.CAC.LAMBDA = 0.0
# 决定“哪些 query 行”要被施加惩罚
cfg.MODEL.CAC.QUERY = 'temporal'  # temporal | search | all (MVP uses temporal)
# 决定“哪些 key 列”参与惩罚
cfg.MODEL.CAC.KEY = 'search'  # search | all (MVP uses search)
# 对干扰分数 δ 的下界截断
cfg.MODEL.CAC.DELTA_CLAMP_MIN = 0.0
# 简易 D 的背景原型 proto 是否 stop-grad。
cfg.MODEL.CAC.DETACH_PROTO = True
# 语言引导（仅影响 proto/δ 的构造；不改变 CAC 的 logit bias 形式）
cfg.MODEL.CAC.LANG_ENABLE = False
# 是否 stop-grad 语言向量（只作为引导，不反传到语言分支）
cfg.MODEL.CAC.LANG_DETACH_VEC = False
# 语言-背景相关性权重激活：relu(·) | softmax(·/tau)
cfg.MODEL.CAC.LANG_WEIGHT_ACT = 'relu'
cfg.MODEL.CAC.LANG_TAU = 0.07
# 调试开关。True 时会把 δ 的统计量
cfg.MODEL.CAC.DEBUG = False
# 解析文本开关（raw | parsed | raw_parsed | empty）
cfg.MODEL.CAC.TEXT_MODE = 'raw'
# 文本融合方式（single | token_concat）
cfg.MODEL.CAC.TEXT_FUSION_MODE = 'single'
# token concat 后的最大总文本长度
cfg.MODEL.CAC.MAX_TOTAL_TEXT_LEN = 32
# 解析字段控制
cfg.MODEL.CAC.PARSED_FIELDS = ['target', 'concepts', 'background']
cfg.MODEL.CAC.PARSED_JOIN = 'sep'
cfg.MODEL.CAC.PARSED_WEIGHT = {'target': 1.0, 'concepts': 0.7, 'background': 0.3}
# CAC 残差插值
cfg.MODEL.CAC.RESIDUAL_ENABLE = False
cfg.MODEL.CAC.RESIDUAL_WEIGHT = 1.0
# 解析器相关配置（仅 TEXT_MODE=parsed 时使用）
cfg.MODEL.CAC.DP_PARSER_CKPT = ''
cfg.MODEL.CAC.DP_CACHE_DIR = ''
cfg.MODEL.CAC.PARSED_USE_SPACY = True
cfg.MODEL.CAC.PARSED_SPACY_MODEL = 'en_core_web_sm'
cfg.MODEL.CAC.DP_EMBED_DIM = 300
cfg.MODEL.CAC.DP_HIDDEN_DIM = 256
cfg.MODEL.CAC.DP_LSTM_LAYERS = 3
cfg.MODEL.CAC.DP_FFNN_DIM = 256
cfg.MODEL.CAC.DP_DEVICE = 'cuda:0'
# 解析原型权重（仅 TEXT_MODE=parsed 时生效）
cfg.MODEL.CAC.PROTO_TARGET_WEIGHT = 0.0
cfg.MODEL.CAC.PROTO_CONCEPT_WEIGHT = 0.0
cfg.MODEL.CAC.PROTO_BG_WEIGHT = 0.0

# MODEL.TEXT_REFINE (Search-aware structured text refinement)
cfg.MODEL.TEXT_REFINE = edict()
cfg.MODEL.TEXT_REFINE.ENABLE = False
cfg.MODEL.TEXT_REFINE.MODE = 'token_reweight'
cfg.MODEL.TEXT_REFINE.APPLY_TO = ['concepts', 'background']
cfg.MODEL.TEXT_REFINE.TOKEN_SCORE = 'cosine'
cfg.MODEL.TEXT_REFINE.TOKEN_WEIGHT_ACT = 'softmax'
cfg.MODEL.TEXT_REFINE.DETACH_SEARCH = False
cfg.MODEL.TEXT_REFINE.DETACH_FIELD = False
cfg.MODEL.TEXT_REFINE.OUTPUT_MODE = 'vec'
cfg.MODEL.TEXT_REFINE.WRITEBACK_MODE = 'global'
cfg.MODEL.TEXT_REFINE.WRITEBACK_FIELDS = ['concepts']
cfg.MODEL.TEXT_REFINE.TARGET_CONDITION_ENABLE = False
cfg.MODEL.TEXT_REFINE.TARGET_CONDITION_FIELDS = ['concepts']
cfg.MODEL.TEXT_REFINE.TARGET_SUPPORT_ACT = 'softmax'
cfg.MODEL.TEXT_REFINE.TARGET_SUPPORT_TAU = 0.07
cfg.MODEL.TEXT_REFINE.TARGET_SUPPORT_TOPK = 0
cfg.MODEL.TEXT_REFINE.TARGET_STATIC = True
cfg.MODEL.TEXT_REFINE.DEBUG = False

# MODEL.STATE_GEN (Interpretable dynamic language state generator)
cfg.MODEL.STATE_GEN = edict()
cfg.MODEL.STATE_GEN.ENABLE = False
cfg.MODEL.STATE_GEN.TYPE = 'heuristic_state_mvp'
cfg.MODEL.STATE_GEN.PROMPT_STYLE = 'json_state_v2'
cfg.MODEL.STATE_GEN.OUTPUT_FORMAT = 'json'
cfg.MODEL.STATE_GEN.OUTPUT_TEXT_ENABLE = True
cfg.MODEL.STATE_GEN.OUTPUT_FEAT_ENABLE = True
cfg.MODEL.STATE_GEN.UPDATE_TEXT_MODE = 'constrained_state'
cfg.MODEL.STATE_GEN.TEXT_APPLY_MODE = 'prune_and_keep'
cfg.MODEL.STATE_GEN.TARGET_POLICY = 'freeze'
cfg.MODEL.STATE_GEN.CONCEPT_POLICY = 'update'
cfg.MODEL.STATE_GEN.BACKGROUND_POLICY = 'update'
cfg.MODEL.STATE_GEN.TARGET_CONDITION_ENABLE = True
cfg.MODEL.STATE_GEN.TARGET_CONDITION_FIELDS = ['concepts']
cfg.MODEL.STATE_GEN.TARGET_SUPPORT_ACT = 'softmax'
cfg.MODEL.STATE_GEN.TARGET_SUPPORT_TAU = 0.07
cfg.MODEL.STATE_GEN.TARGET_SUPPORT_TOPK = 0
cfg.MODEL.STATE_GEN.TRIGGER_MODE = 'low_conf_only'
cfg.MODEL.STATE_GEN.LOW_CONF_TH = 0.45
cfg.MODEL.STATE_GEN.CONCEPT_STRONG_TH = 0.65
cfg.MODEL.STATE_GEN.CONCEPT_WEAK_TH = 0.45
cfg.MODEL.STATE_GEN.BACKGROUND_ACTIVE_TH = 0.60
cfg.MODEL.STATE_GEN.BACKGROUND_WEAK_TH = 0.40
cfg.MODEL.STATE_GEN.WEAK_SCALE = 0.35
cfg.MODEL.STATE_GEN.OFF_SCALE = 0.0
cfg.MODEL.STATE_GEN.APPLY_WITH_CAC = False
cfg.MODEL.STATE_GEN.DEBUG = False

# MODEL.QWEN_REFINE (Constrained concept/background rewrite with Qwen2.5-VL)
cfg.MODEL.QWEN_REFINE = edict()
cfg.MODEL.QWEN_REFINE.ENABLE = False
cfg.MODEL.QWEN_REFINE.MODEL_PATH = ''
cfg.MODEL.QWEN_REFINE.CACHE_PATH = ''
cfg.MODEL.QWEN_REFINE.CACHE_ENABLE = True
cfg.MODEL.QWEN_REFINE.CACHE_INTERVAL = 50
cfg.MODEL.QWEN_REFINE.CACHE_MAX_GAP = 25
cfg.MODEL.QWEN_REFINE.CACHE_USE_PROB = 0.5
cfg.MODEL.QWEN_REFINE.TRIGGER_MODE = 'interval_and_low_conf'
cfg.MODEL.QWEN_REFINE.TRIGGER_INTERVAL = 8
cfg.MODEL.QWEN_REFINE.LOW_CONF_TH = 0.45
cfg.MODEL.QWEN_REFINE.MAX_CALLS_PER_SEQ = 10
cfg.MODEL.QWEN_REFINE.UPDATE_FIELDS = ['concepts']
cfg.MODEL.QWEN_REFINE.KEEP_TARGET_FROZEN = True
cfg.MODEL.QWEN_REFINE.INPUT_IMAGE = 'search'
cfg.MODEL.QWEN_REFINE.INPUT_HINTS_ENABLE = True
cfg.MODEL.QWEN_REFINE.SYSTEM_PROMPT_VERSION = 'v2'
cfg.MODEL.QWEN_REFINE.OUTPUT_FORMAT = 'json'
cfg.MODEL.QWEN_REFINE.ALLOW_EMPTY_CONCEPT = True
cfg.MODEL.QWEN_REFINE.ALLOW_EMPTY_BACKGROUND = True
cfg.MODEL.QWEN_REFINE.MAX_FIELD_WORDS = 6
cfg.MODEL.QWEN_REFINE.MAX_FIELD_GROWTH = 2.0
cfg.MODEL.QWEN_REFINE.DROP_INVALID_OUTPUT = True
cfg.MODEL.QWEN_REFINE.DEBUG = False

# MODEL.BACKBONE
cfg.MODEL.BACKBONE = edict()
cfg.MODEL.BACKBONE.TYPE = "vit_base_patch16_224"
cfg.MODEL.BACKBONE.STRIDE = 16
cfg.MODEL.BACKBONE.MID_PE = False
cfg.MODEL.BACKBONE.SEP_SEG = False
cfg.MODEL.BACKBONE.CAT_MODE = 'direct'
cfg.MODEL.BACKBONE.MERGE_LAYER = 0
cfg.MODEL.BACKBONE.ADD_CLS_TOKEN = False
cfg.MODEL.BACKBONE.TOKEN_LEN = 1
cfg.MODEL.BACKBONE.TOP_K = 3
cfg.MODEL.BACKBONE.CLS_TOKEN_USE_MODE = 'ignore'
cfg.MODEL.BACKBONE.ATTN_TYPE = 'concat'

cfg.MODEL.BACKBONE.CE_LOC = []
cfg.MODEL.BACKBONE.CE_KEEP_RATIO = []
cfg.MODEL.BACKBONE.CE_TEMPLATE_RANGE = 'ALL'  # choose between ALL, CTR_POINT, CTR_REC, GT_BOX
cfg.MODEL.BACKBONE.BERT_DIR = 'ALL'
cfg.MODEL.BACKBONE.BLIP_DIR = 'ALL'

# MODEL.HEAD
cfg.MODEL.HEAD = edict()
cfg.MODEL.HEAD.TYPE = "CENTER"
cfg.MODEL.HEAD.NUM_CHANNELS = 256


# TRAIN
cfg.TRAIN = edict()
cfg.TRAIN.LR = 0.0001
cfg.TRAIN.WEIGHT_DECAY = 0.0001
cfg.TRAIN.EPOCH = 500
cfg.TRAIN.LR_DROP_EPOCH = 400
cfg.TRAIN.BATCH_SIZE = 16
cfg.TRAIN.NUM_WORKER = 8
cfg.TRAIN.OPTIMIZER = "ADAMW"
cfg.TRAIN.BACKBONE_MULTIPLIER = 0.1
cfg.TRAIN.GIOU_WEIGHT = 2.0
cfg.TRAIN.L1_WEIGHT = 5.0
cfg.TRAIN.FREEZE_LAYERS = [0, ]
cfg.TRAIN.PRINT_INTERVAL = 50
cfg.TRAIN.VAL_EPOCH_INTERVAL = 20
cfg.TRAIN.GRAD_CLIP_NORM = 0.1
cfg.TRAIN.AMP = False
cfg.TRAIN.BBOX_TASK = False

cfg.TRAIN.CE_START_EPOCH = 20  # candidate elimination start epoch
cfg.TRAIN.CE_WARM_EPOCH = 80  # candidate elimination warm up epoch
cfg.TRAIN.DROP_PATH_RATE = 0.1  # drop path rate for ViT backbone

cfg.TRAIN.TEXT_AUG = edict()
cfg.TRAIN.TEXT_AUG.ENABLE = False
cfg.TRAIN.TEXT_AUG.DROP_PROB = 0.1
cfg.TRAIN.TEXT_AUG.SHUFFLE_PROB = 0.1
cfg.TRAIN.TEXT_AUG.CHAR_NOISE_PROB = 0.05
cfg.TRAIN.TEXT_AUG.CASE_PERTURB_PROB = 0.05
cfg.TRAIN.TEXT_AUG.PUNCT_PERTURB_PROB = 0.05
cfg.TRAIN.TEXT_AUG.SYNONYM_PROB = 0.1
cfg.TRAIN.TEXT_AUG.SYNONYM_PATH = ''

# TRAIN.SCHEDULER
cfg.TRAIN.SCHEDULER = edict()
cfg.TRAIN.SCHEDULER.TYPE = "step"
cfg.TRAIN.SCHEDULER.DECAY_RATE = 0.1

# DATA
cfg.DATA = edict()
cfg.DATA.SAMPLER_MODE = "causal"  # sampling methods
cfg.DATA.MEAN = [0.485, 0.456, 0.406]
cfg.DATA.STD = [0.229, 0.224, 0.225]
cfg.DATA.MAX_SAMPLE_INTERVAL = 200
# DATA.TRAIN
cfg.DATA.TRAIN = edict()
cfg.DATA.TRAIN.DATASETS_NAME = ["LASOT", "GOT10K_vottrain"]
cfg.DATA.TRAIN.DATASETS_RATIO = [1, 1]
cfg.DATA.TRAIN.SAMPLE_PER_EPOCH = 60000
# DATA.VAL
cfg.DATA.VAL = edict()
cfg.DATA.VAL.DATASETS_NAME = ["GOT10K_votval"]
cfg.DATA.VAL.DATASETS_RATIO = [1]
cfg.DATA.VAL.SAMPLE_PER_EPOCH = 10000
# DATA.SEARCH
cfg.DATA.SEARCH = edict()
cfg.DATA.SEARCH.SIZE = 320
cfg.DATA.SEARCH.FACTOR = 5.0
cfg.DATA.SEARCH.CENTER_JITTER = 4.5
cfg.DATA.SEARCH.SCALE_JITTER = 0.5
cfg.DATA.SEARCH.NUMBER = 1
# DATA.TEMPLATE
cfg.DATA.TEMPLATE = edict()
cfg.DATA.TEMPLATE.NUMBER = 1
cfg.DATA.TEMPLATE.SIZE = 128
cfg.DATA.TEMPLATE.FACTOR = 2.0
cfg.DATA.TEMPLATE.CENTER_JITTER = 0
cfg.DATA.TEMPLATE.SCALE_JITTER = 0

# TEST
cfg.TEST = edict()
cfg.TEST.TEMPLATE_FACTOR = 2.0
cfg.TEST.TEMPLATE_SIZE = 128
cfg.TEST.TEMPLATE_NUMBER = 1
cfg.TEST.MEMORY_THRESHOLD = 1000
cfg.TEST.SEARCH_FACTOR = 5.0
cfg.TEST.SEARCH_SIZE = 320
cfg.TEST.EPOCH = 500

# TEST.TEXT (text source at inference time)
# NOTE: Some datasets (e.g., TNL2K-lang) provide GT text_description at init frame.
# Others (e.g., GOT10K) may not. Keep this dataset-agnostic.
cfg.TEST.TEXT = edict()
cfg.TEST.TEXT.SOURCE = "auto"  # auto | gt | blip | class | empty
cfg.TEST.TEXT.UPDATE_POLICY = "on_update_key"  # on_update_key | always | never
cfg.TEST.TEXT.CLASS_TEMPLATE = "a photo of {}"
cfg.TEST.TEXT.DEBUG = False


def _edict2dict(dest_dict, src_edict):
    if isinstance(dest_dict, dict) and isinstance(src_edict, dict):
        for k, v in src_edict.items():
            if not isinstance(v, edict):
                dest_dict[k] = v
            else:
                dest_dict[k] = {}
                _edict2dict(dest_dict[k], v)
    else:
        return


def gen_config(config_file):
    cfg_dict = {}
    _edict2dict(cfg_dict, cfg)
    with open(config_file, 'w') as f:
        yaml.dump(cfg_dict, f, default_flow_style=False)


def _update_config(base_cfg, exp_cfg):
    if isinstance(base_cfg, dict) and isinstance(exp_cfg, edict):
        for k, v in exp_cfg.items():
            if k in base_cfg:
                if not isinstance(v, dict):
                    base_cfg[k] = v
                else:
                    _update_config(base_cfg[k], v)
            else:
                raise ValueError("{} not exist in config.py".format(k))
    else:
        return


def update_config_from_file(filename, base_cfg=None):
    exp_config = None
    with open(filename) as f:
        exp_config = edict(yaml.safe_load(f))
        if base_cfg is not None:
            _update_config(base_cfg, exp_config)
        else:
            _update_config(cfg, exp_config)

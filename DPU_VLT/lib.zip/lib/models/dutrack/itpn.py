# --------------------------------------------------------
# Fast-iTPN: Integrally Pre-Trained Transformer Pyramid Network with Token Migration
# Github source: https://github.com/sunsmarterjie/iTPN/tree/main/fast_itpn
# Copyright (c) 2023 University of Chinese Academy of Sciences
# Licensed under The MIT License [see LICENSE for details]
# By Yunjie Tian
# Based on EVA02, timm and deit code bases
# https://github.com/baaivision/EVA/tree/master/EVA-02
# https://github.com/rwightman/pytorch-image-models/tree/master/timm
# https://github.com/facebookresearch/deit/
# --------------------------------------------------------'
from functools import partial

import json
import math
import os
from os.path import split
import sys

import torch
import torch.nn as nn
from timm.models.registry import register_model
import torch.nn.functional as F
from timm.models.layers import to_2tuple, drop_path, trunc_normal_

from torch import Tensor, Size
from typing import Union, List

from lib.models.dutrack.base_backbone import BaseBackbone
from transformers import BertTokenizer
from transformers.models.bert.modeling_bert import BertConfig, BertEmbeddings
from lib.models.dutrack import utils as utils
from lib.models.dutrack.utils import combine_tokens, recover_tokens

try:
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)
    from DPModel2.parse_text import DPModel2Parser
except Exception:
    DPModel2Parser = None

def _cfg(url='', **kwargs):
    return {
        'url': url,
        'num_classes': 1000, 'input_size': (3, 224, 224), 'pool_size': None,
        'crop_pct': .9, 'interpolation': 'bicubic',
        'mean': (0.5, 0.5, 0.5), 'std': (0.5, 0.5, 0.5),
        **kwargs
    }


_shape_t = Union[int, List[int], Size]


class DropPath(nn.Module):
    """Drop paths (Stochastic Depth) per sample  (when applied in main path of residual blocks).
    """

    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path(x, self.drop_prob, self.training)

    def extra_repr(self) -> str:
        return 'p={}'.format(self.drop_prob)


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.,
                 norm_layer=nn.LayerNorm, subln=False
                 ):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()

        self.ffn_ln = norm_layer(hidden_features) if subln else nn.Identity()

        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.ffn_ln(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class ConvMlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.,
                 norm_layer=nn.LayerNorm, subln=False
                 ):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.fc1 = nn.Conv2d(in_features, hidden_features, 1)
        self.act = act_layer()

        self.ffn_ln = norm_layer(hidden_features) if subln else None

        self.fc2 = nn.Conv2d(hidden_features, out_features, 1)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        if self.ffn_ln is not None:
            x = x.permute(0, 2, 3, 1)
            x = self.ffn_ln(x)
            x = x.permute(0, 3, 1, 2)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class SwiGLU(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.SiLU, drop=0.,
                 norm_layer=nn.LayerNorm, subln=False
                 ):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.w1 = nn.Linear(in_features, hidden_features)
        self.w2 = nn.Linear(in_features, hidden_features)

        self.act = act_layer()
        self.ffn_ln = norm_layer(hidden_features) if subln else nn.Identity()
        self.w3 = nn.Linear(hidden_features, out_features)

        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x1 = self.w1(x)
        x2 = self.w2(x)
        hidden = self.act(x1) * x2
        x = self.ffn_ln(hidden)
        x = self.w3(x)
        x = self.drop(x)
        return x


class ConvSwiGLU(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.SiLU, drop=0.,
                 norm_layer=nn.LayerNorm, subln=False
                 ):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.w1 = nn.Conv2d(in_features, hidden_features, 1)
        self.w2 = nn.Conv2d(in_features, hidden_features, 1)

        self.act = act_layer()
        self.ffn_ln = norm_layer(hidden_features) if subln else nn.Identity()
        self.w3 = nn.Conv2d(hidden_features, out_features, 1)

        self.drop = nn.Dropout(drop)

    def forward(self, x):
        B, C, H, W = x.shape
        x1 = self.w1(x).flatten(2).transpose(1, 2)
        x2 = self.w2(x).flatten(2).transpose(1, 2)
        hidden = self.act(x1) * x2
        x = self.ffn_ln(hidden).transpose(1, 2).view(B, C, H, W)
        x = self.w3(x)
        x = self.drop(x)
        return x


class Attention(nn.Module):
    def __init__(
            self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., window_size=None,
            attn_head_dim=None, use_decoupled_rel_pos_bias=False, deepnorm=False, subln=False
    ):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        if attn_head_dim is not None:
            head_dim = attn_head_dim
        all_head_dim = head_dim * self.num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.deepnorm = deepnorm
        self.subln = subln
        if self.deepnorm or self.subln:
            self.q_proj = nn.Linear(dim, all_head_dim, bias=False)
            self.k_proj = nn.Linear(dim, all_head_dim, bias=False)
            self.v_proj = nn.Linear(dim, all_head_dim, bias=False)
        else:
            self.qkv = nn.Linear(dim, all_head_dim * 3, bias=False)

        if qkv_bias:
            self.q_bias = nn.Parameter(torch.zeros(all_head_dim))
            self.v_bias = nn.Parameter(torch.zeros(all_head_dim))
        else:
            self.q_bias = None
            self.v_bias = None

        self.rel_pos_bias = None
        self.qk_float = True

        self.window_size = None
        self.relative_position_bias_table = None

        if window_size:
            if use_decoupled_rel_pos_bias:
                self.rel_pos_bias = DecoupledRelativePositionBias(window_size=window_size, num_heads=num_heads)
            else:
                self.window_size = window_size
                self.num_relative_distance = (2 * window_size[0] - 1) * (
                        2 * window_size[1] - 1) + 3  # (2*14-1) * (2*14-1) + 3
                self.relative_position_bias_table = nn.Parameter(
                    torch.zeros(self.num_relative_distance, num_heads))  # 2*Wh-1 * 2*Ww-1, nH
                # cls to token & token 2 cls & cls to cls

                # get pair-wise relative position index for each token inside the window
                coords_h = torch.arange(window_size[0])
                coords_w = torch.arange(window_size[1])
                coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, Wh, Ww
                coords_flatten = torch.flatten(coords, 1)  # 2, Wh*Ww
                relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # 2, Wh*Ww, Wh*Ww
                relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # Wh*Ww, Wh*Ww, 2
                relative_coords[:, :, 0] += window_size[0] - 1  # shift to start from 0
                relative_coords[:, :, 1] += window_size[1] - 1
                relative_coords[:, :, 0] *= 2 * window_size[1] - 1
                relative_position_index = \
                    torch.zeros(size=(window_size[0] * window_size[1] + 1,) * 2, dtype=relative_coords.dtype)
                relative_position_index[1:, 1:] = relative_coords.sum(-1)  # Wh*Ww, Wh*Ww
                relative_position_index[0, 0:] = self.num_relative_distance - 3
                relative_position_index[0:, 0] = self.num_relative_distance - 2
                relative_position_index[0, 0] = self.num_relative_distance - 1

                self.register_buffer("relative_position_index", relative_position_index)

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(all_head_dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
    # cac_key_penalty：key 侧惩罚向量，每个 key token 的“干扰性”分数 δ（或其变体）。数值越大表示越像干扰，应该被压制
    # cac_query_gate：query 侧门控向量，哪些 query 行启用 CAC。比如 MVP 里只让 temporal token 那一行是 1，其它是 0；这样就只纠正 temporal token “看哪些 key”的注意力分布，不去动其它 token的注意力。
    # cac_lambda：标量超参，整体惩罚强度。
    def forward(
        self,
        x,
        rel_pos_bias=None,
        attn_mask=None,
        cac_key_penalty=None,   # (B, K)
        cac_query_gate=None,    # (B, Q)
        cac_lambda: float = 0.0,
    ):
        B, N, C = x.shape

        if self.deepnorm or self.subln:
            q = F.linear(input=x, weight=self.q_proj.weight, bias=self.q_bias)
            k = F.linear(input=x, weight=self.k_proj.weight, bias=None)
            v = F.linear(input=x, weight=self.v_proj.weight, bias=self.v_bias)

            q = q.reshape(B, N, self.num_heads, -1).permute(0, 2, 1, 3)  # B, num_heads, N, C
            k = k.reshape(B, N, self.num_heads, -1).permute(0, 2, 1, 3)
            v = v.reshape(B, N, self.num_heads, -1).permute(0, 2, 1, 3)
        else:
            qkv_bias = None
            if self.q_bias is not None:
                qkv_bias = torch.cat((self.q_bias, torch.zeros_like(self.v_bias, requires_grad=False), self.v_bias))
            qkv = F.linear(input=x, weight=self.qkv.weight, bias=qkv_bias)
            qkv = qkv.reshape(B, N, 3, self.num_heads, -1).permute(2, 0, 3, 1, 4)  # 3, B, num_heads, N, C
            q, k, v = qkv[0], qkv[1], qkv[2]

        q = q * self.scale
        if self.qk_float:
            attn = (q.float() @ k.float().transpose(-2, -1))
        else:
            attn = (q @ k.transpose(-2, -1))

        # Counterfactual Attention Correction (CAC): apply logit bias before softmax.
        # attn: (B, heads, Q, K). For self-attn, Q==K==N.
        if cac_key_penalty is not None and cac_query_gate is not None and cac_lambda and cac_lambda != 0.0:
            key_penalty = cac_key_penalty[:, None, None, :]  # (B,1,1,K)
            query_gate = cac_query_gate[:, None, :, None]    # (B,1,Q,1)
            attn = attn - (float(cac_lambda) * query_gate * key_penalty).type_as(attn)

        if self.relative_position_bias_table is not None:
            relative_position_bias = \
                self.relative_position_bias_table[self.relative_position_index.view(-1)].view(
                    self.window_size[0] * self.window_size[1] + 1,
                    self.window_size[0] * self.window_size[1] + 1, -1)  # Wh*Ww,Wh*Ww,nH
            relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # nH, Wh*Ww, Wh*Ww
            attn = attn + relative_position_bias.unsqueeze(0).type_as(attn)

        if self.rel_pos_bias is not None:
            attn = attn + self.rel_pos_bias().type_as(attn)

        if rel_pos_bias is not None:
            attn = attn + rel_pos_bias.type_as(attn)
        if attn_mask is not None:
            attn_mask = attn_mask.bool()
            attn = attn.masked_fill(~attn_mask[:, None, None, :], float("-inf"))
        attn = attn.softmax(dim=-1).type_as(x)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, -1)
        x = self.proj(x)
        x = self.proj_drop(x)

        return x,attn


class Block(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., init_values=None, norm_layer=nn.LayerNorm, window_size=None, attn_head_dim=None,
                 use_decoupled_rel_pos_bias=False,
                 depth=None,
                 postnorm=False,
                 deepnorm=False,
                 subln=False,
                 swiglu=False,
                 naiveswiglu=False,
                 ):
        super().__init__()

        with_attn = num_heads > 0

        self.norm1 = norm_layer(dim) if with_attn else None
        self.attn = Attention(
            dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
            attn_drop=attn_drop, proj_drop=drop, window_size=window_size,
            use_decoupled_rel_pos_bias=use_decoupled_rel_pos_bias, attn_head_dim=attn_head_dim,
            deepnorm=deepnorm,
            subln=subln
        ) if with_attn else None

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)

        mlp_hidden_dim = int(dim * mlp_ratio)
        if swiglu:
            self.mlp = xops.SwiGLU(
                in_features=dim,
                hidden_features=mlp_hidden_dim
            )  # hidden_features: 2/3
        elif naiveswiglu:
            self.mlp = SwiGLU(
                in_features=dim,
                hidden_features=mlp_hidden_dim,
                subln=subln,
                norm_layer=norm_layer,
            )
        else:
            self.mlp = Mlp(
                in_features=dim,
                hidden_features=mlp_hidden_dim,
                subln=subln,
                norm_layer=norm_layer
            )

        if init_values is not None and init_values > 0:
            self.gamma_1 = nn.Parameter(init_values * torch.ones((dim)),
                                        requires_grad=True) if self.attn is not None else None
            self.gamma_2 = nn.Parameter(init_values * torch.ones((dim)), requires_grad=True)
        else:
            self.gamma_1, self.gamma_2 = None, None

        self.deepnorm = deepnorm
        if self.deepnorm:
            self.alpha = math.pow(2.0 * depth, 0.25)

        self.postnorm = postnorm

    def forward(self, x, rel_pos_bias=None, attn_mask=None, cac_ctx=None, cac_layer: bool = False):
        attn = None
        if self.gamma_2 is None:
            if self.postnorm:
                if self.attn is not None:
                    x = x + self.drop_path(
                        self.norm1(self.attn(x, rel_pos_bias=rel_pos_bias, attn_mask=attn_mask)))
                x = x + self.drop_path(self.norm2(self.mlp(x)))
            elif self.deepnorm:
                if self.attn is not None:
                    residual = x
                    x = self.attn(x, rel_pos_bias=rel_pos_bias, attn_mask=attn_mask)
                    x = self.drop_path(x)
                    x = residual * self.alpha + x
                    x = self.norm1(x)

                residual = x
                x = self.mlp(x)
                x = self.drop_path(x)
                x = residual * self.alpha + x
                x = self.norm2(x)
            else:
                if self.attn is not None:
                    x = x + self.drop_path(
                        self.attn(self.norm1(x), rel_pos_bias=rel_pos_bias, attn_mask=attn_mask))
                x = x + self.drop_path(self.mlp(self.norm2(x)))
        else:
            if self.postnorm:
                if self.attn is not None:
                    x = x + self.drop_path(
                        self.gamma_1 * self.norm1(self.attn(x, rel_pos_bias=rel_pos_bias, attn_mask=attn_mask)))
                x = x + self.drop_path(self.gamma_2 * self.norm2(self.mlp(x)))
            else:
                if self.attn is not None:
                    x_norm = self.norm1(x)
                    cac_kwargs = {}
                    cfg = cac_ctx.get('cfg', None) if cac_ctx is not None else None
                    if cac_layer and cac_ctx is not None:
                        lens_x = int(cac_ctx.get('lens_x', 0))
                        bg_mask = cac_ctx.get('bg_mask', None)  # (B, lens_x), 1 for background
                        if lens_x > 0 and bg_mask is not None and cfg is not None:
                            B, N, C = x_norm.shape
                            search_tok = x_norm[:, -lens_x:, :]  # (B, lens_x, C)

                            denom = bg_mask.sum(dim=1, keepdim=True).clamp(min=1.0)
                            proto_bg = (search_tok * bg_mask.unsqueeze(-1)).sum(dim=1) / denom  # (B, C)

                            proto = proto_bg
                            if getattr(cfg, 'LANG_ENABLE', False):
                                lang_vec = cac_ctx.get('lang_vec', None)  # (B, C)
                                lang_valid = cac_ctx.get('lang_valid', None)  # (B,)
                                if lang_vec is not None and lang_valid is not None:
                                    sim_lang = F.cosine_similarity(search_tok, lang_vec.unsqueeze(1), dim=-1)  # (B, lens_x)
                                    act = str(getattr(cfg, 'LANG_WEIGHT_ACT', 'relu')).lower()
                                    if act == 'softmax':
                                        tau = float(getattr(cfg, 'LANG_TAU', 0.07))
                                        sim_scaled = sim_lang / max(tau, 1e-6)
                                        sim_scaled = sim_scaled.masked_fill(bg_mask <= 0, float('-inf'))
                                        w = torch.softmax(sim_scaled, dim=1) * bg_mask
                                    else:
                                        w = F.relu(sim_lang) * bg_mask
                                    w = w * lang_valid.to(w.dtype).unsqueeze(1)
                                    denom_w = w.sum(dim=1, keepdim=True)
                                    proto_lang = (search_tok * w.unsqueeze(-1)).sum(dim=1) / denom_w.clamp(min=1e-6)
                                    use_lang = (denom_w.squeeze(1) > 0)
                                    proto = torch.where(use_lang.unsqueeze(1), proto_lang, proto_bg)

                            if getattr(cfg, 'DETACH_PROTO', True):
                                proto = proto.detach()
                            parsed_vecs = cac_ctx.get('parsed_vecs', None)
                            use_proto = False
                            w_t = float(getattr(cfg, 'PROTO_TARGET_WEIGHT', 0.0))
                            w_c = float(getattr(cfg, 'PROTO_CONCEPT_WEIGHT', 0.0))
                            w_b = float(getattr(cfg, 'PROTO_BG_WEIGHT', 0.0))
                            if parsed_vecs is not None and (w_t != 0.0 or w_c != 0.0 or w_b != 0.0):
                                use_proto = True

                            if use_proto:
                                sim_bg = None
                                if parsed_vecs is not None and 'background' in parsed_vecs:
                                    vec_b, valid_b = parsed_vecs['background']
                                    if valid_b is not None:
                                        sim_bg = F.cosine_similarity(search_tok, vec_b.unsqueeze(1), dim=-1)
                                        sim_bg = sim_bg * valid_b.to(sim_bg.dtype).unsqueeze(1)
                                if sim_bg is None:
                                    sim_bg = F.cosine_similarity(search_tok, proto.unsqueeze(1), dim=-1)

                                sim_t = 0.0
                                if parsed_vecs is not None and 'target' in parsed_vecs:
                                    vec_t, valid_t = parsed_vecs['target']
                                    sim_t = F.cosine_similarity(search_tok, vec_t.unsqueeze(1), dim=-1)
                                    sim_t = sim_t * valid_t.to(sim_t.dtype).unsqueeze(1)

                                sim_c = 0.0
                                if parsed_vecs is not None and 'concepts' in parsed_vecs:
                                    vec_c, valid_c = parsed_vecs['concepts']
                                    sim_c = F.cosine_similarity(search_tok, vec_c.unsqueeze(1), dim=-1)
                                    sim_c = sim_c * valid_c.to(sim_c.dtype).unsqueeze(1)

                                sim = (w_b * sim_bg) + (w_c * sim_c) - (w_t * sim_t)
                            else:
                                sim = F.cosine_similarity(search_tok, proto.unsqueeze(1), dim=-1)

                            sim = sim.clamp(min=float(getattr(cfg, 'DELTA_CLAMP_MIN', 0.0)))
                            delta = sim * bg_mask

                            key_penalty = x_norm.new_zeros((B, N))
                            key_penalty[:, -lens_x:] = delta

                            query_gate = x_norm.new_zeros((B, N))
                            query_mode = str(getattr(cfg, 'QUERY', 'temporal')).lower()
                            if query_mode == 'temporal':
                                temporal_len = int(cac_ctx.get('temporal_len', 1)) if cac_ctx is not None else 1
                                query_gate[:, :temporal_len] = 1.0
                            elif query_mode == 'search':
                                query_gate[:, -lens_x:] = 1.0
                            elif query_mode == 'all':
                                query_gate[:] = 1.0
                            else:
                                query_gate[:, 0] = 1.0

                            cac_kwargs = {
                                'cac_key_penalty': key_penalty,
                                'cac_query_gate': query_gate,
                                'cac_lambda': float(getattr(cfg, 'LAMBDA', 0.0)),
                            }

                            if getattr(cfg, 'DEBUG', False):
                                cac_ctx['debug_last_delta_mean'] = float(delta.mean().detach().cpu())
                                cac_ctx['debug_last_delta_bg_mean'] = float(
                                    (delta.sum() / bg_mask.sum().clamp(min=1.0)).detach().cpu()
                                )

                    if cac_kwargs and cfg is not None and bool(getattr(cfg, 'RESIDUAL_ENABLE', False)):
                        base_feat, _ = self.attn(x_norm, rel_pos_bias=rel_pos_bias, attn_mask=attn_mask)
                        cac_feat, attn = self.attn(x_norm, rel_pos_bias=rel_pos_bias, attn_mask=attn_mask, **cac_kwargs)
                        residual_weight = float(getattr(cfg, 'RESIDUAL_WEIGHT', 1.0))
                        feat = base_feat + residual_weight * (cac_feat - base_feat)
                    else:
                        feat, attn = self.attn(x_norm, rel_pos_bias=rel_pos_bias, attn_mask=attn_mask, **cac_kwargs)
                    x = x + self.drop_path(self.gamma_1 * feat)
                x = x + self.drop_path(self.gamma_2 * self.mlp(self.norm2(x)))
        return x,attn


class ConvMlpBlock(nn.Module):

    def __init__(self, dim, mlp_ratio=4., drop_path=0., init_values=None, norm_layer=nn.LayerNorm,
                 depth=None,
                 postnorm=False,
                 deepnorm=False,
                 subln=False,
                 swiglu=False,
                 naiveswiglu=False,
                 ):
        super().__init__()

        self.attn = None

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)

        mlp_hidden_dim = int(dim * mlp_ratio)

        if swiglu:
            self.mlp = xops.SwiGLU(
                in_features=dim,
                hidden_features=mlp_hidden_dim
            )  # hidden_features: 2/3
        elif naiveswiglu:
            self.mlp = ConvSwiGLU(
                in_features=dim,
                hidden_features=mlp_hidden_dim,
                subln=subln,
                norm_layer=norm_layer,
            )
        else:
            self.mlp = ConvMlp(
                in_features=dim,
                hidden_features=mlp_hidden_dim,
                subln=subln,
                norm_layer=norm_layer
            )

        if init_values is not None and init_values > 0:
            self.gamma_1 = nn.Parameter(init_values * torch.ones((dim)),
                                        requires_grad=True) if self.attn is not None else None
            self.gamma_2 = nn.Parameter(init_values * torch.ones((dim)), requires_grad=True)
        else:
            self.gamma_1, self.gamma_2 = None, None

        self.deepnorm = deepnorm
        if self.deepnorm:
            self.alpha = math.pow(2.0 * depth, 0.25)

        self.postnorm = postnorm

    def forward(self, x):
        if self.gamma_2 is None:
            if self.postnorm:
                x = x + self.drop_path(self.norm2(self.mlp(x)))
            elif self.deepnorm:
                residual = x
                x = self.mlp(x)
                x = self.drop_path(x)
                x = residual * self.alpha + x
                x = self.norm2(x)
            else:
                x = x + self.drop_path(self.mlp(self.norm2(x.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)))
        else:
            if self.postnorm:
                x = x + self.drop_path(self.gamma_2 * self.norm2(self.mlp(x)))
            else:
                m = self.mlp(self.norm2(x.permute(0, 2, 3, 1)).permute(0, 3, 1, 2))
                x = x + self.drop_path(self.gamma_2 * m)
        return x


class PatchEmbed(nn.Module):
    def __init__(self, img_size=224, patch_size=16, inner_patches=4, in_chans=3, embed_dim=128, norm_layer=None):
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        patches_resolution = [img_size[0] // patch_size[0], img_size[1] // patch_size[1]]
        self.img_size = img_size
        self.patch_size = patch_size
        self.inner_patches = inner_patches
        self.patches_resolution = self.patch_shape = patches_resolution
        self.num_patches = patches_resolution[0] * patches_resolution[1]

        self.in_chans = in_chans
        self.embed_dim = embed_dim

        conv_size = [size // inner_patches for size in patch_size]
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=conv_size, stride=conv_size)
        if norm_layer is not None:
            self.norm = norm_layer(embed_dim)
        else:
            self.norm = None

    def forward(self, x):
        B, C, H, W = x.shape
        patches_resolution = (H // self.patch_size[0], W // self.patch_size[1])
        num_patches = patches_resolution[0] * patches_resolution[1]
        x = self.proj(x).view(
            B, -1,
            patches_resolution[0], self.inner_patches,
            patches_resolution[1], self.inner_patches,
        ).permute(0, 2, 4, 3, 5, 1).reshape(B, num_patches, self.inner_patches, self.inner_patches, -1)
        if self.norm is not None:
            x = self.norm(x)
        return x


class ConvPatchEmbed(nn.Module):
    def __init__(self, img_size=224, patch_size=16, inner_patches=4, in_chans=3, embed_dim=128, norm_layer=None,
                 stop_grad_conv1=False):
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        patches_resolution = [img_size[0] // patch_size[0], img_size[1] // patch_size[1]]
        self.img_size = img_size
        self.patch_size = patch_size
        self.stop_grad_conv1 = stop_grad_conv1
        self.inner_patches = inner_patches
        self.patches_resolution = self.patch_shape = patches_resolution
        self.num_patches = patches_resolution[0] * patches_resolution[1]

        self.in_chans = in_chans
        self.embed_dim = embed_dim

        conv_size = [size // inner_patches for size in patch_size]
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=conv_size, stride=conv_size)
        if norm_layer is not None:
            self.norm = norm_layer(embed_dim)
        else:
            self.norm = None

    def forward(self, x, bool_masked_pos=None, mask_token=None):
        B, C, H, W = x.shape
        x = self.proj(x)
        if self.stop_grad_conv1:
            x = x.detach() * 0.9 + x * 0.1

        if bool_masked_pos is not None:
            x = torch.nn.functional.unfold(x, kernel_size=4, stride=4, padding=0).transpose(1, 2)

            seq_len = x.shape[1]
            mask_token = mask_token.expand(B, seq_len, -1)
            w = bool_masked_pos.unsqueeze(-1).type_as(mask_token)
            x = x * (1 - w) + mask_token * w

            x = torch.nn.functional.fold(x.transpose(1, 2), output_size=(H // 4, W // 4), kernel_size=4, padding=0,
                                         stride=4)
        if self.norm is not None:
            x = self.norm(x)
        return x


class PatchMerge(nn.Module):
    def __init__(self, dim, norm_layer):
        super().__init__()
        self.norm = norm_layer(dim * 4)
        self.reduction = nn.Linear(dim * 4, dim * 2, bias=False)
        self.mlp = None

    def forward(self, x):
        x0 = x[..., 0::2, 0::2, :]
        x1 = x[..., 1::2, 0::2, :]
        x2 = x[..., 0::2, 1::2, :]
        x3 = x[..., 1::2, 1::2, :]

        x = torch.cat([x0, x1, x2, x3], dim=-1)
        x = self.norm(x)
        x = self.reduction(x)
        return x


class ConvPatchMerge(nn.Module):
    def __init__(self, dim, norm_layer):
        super().__init__()
        self.norm = norm_layer(dim)
        self.reduction = nn.Conv2d(dim, dim * 2, kernel_size=2, stride=2, padding=0)
        self.mlp = None

    def forward(self, x):
        x = self.norm(x.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)
        x = self.reduction(x)
        return x


class RelativePositionBias(nn.Module):

    def __init__(self, window_size, num_heads):
        super().__init__()
        self.window_size = window_size
        self.num_relative_distance = (2 * window_size[0] - 1) * (2 * window_size[1] - 1) + 3
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros(self.num_relative_distance, num_heads))  # 2*Wh-1 * 2*Ww-1, nH
        # cls to token & token 2 cls & cls to cls

        # get pair-wise relative position index for each token inside the window
        coords_h = torch.arange(window_size[0])
        coords_w = torch.arange(window_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, Wh, Ww
        coords_flatten = torch.flatten(coords, 1)  # 2, Wh*Ww
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # 2, Wh*Ww, Wh*Ww
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # Wh*Ww, Wh*Ww, 2
        relative_coords[:, :, 0] += window_size[0] - 1  # shift to start from 0
        relative_coords[:, :, 1] += window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * window_size[1] - 1
        relative_position_index = \
            torch.zeros(size=(window_size[0] * window_size[1] + 1,) * 2, dtype=relative_coords.dtype)
        relative_position_index[1:, 1:] = relative_coords.sum(-1)  # Wh*Ww, Wh*Ww
        relative_position_index[0, 0:] = self.num_relative_distance - 3
        relative_position_index[0:, 0] = self.num_relative_distance - 2
        relative_position_index[0, 0] = self.num_relative_distance - 1

        self.register_buffer("relative_position_index", relative_position_index)

    def forward(self):
        relative_position_bias = \
            self.relative_position_bias_table[self.relative_position_index.view(-1)].view(
                self.window_size[0] * self.window_size[1] + 1,
                self.window_size[0] * self.window_size[1] + 1, -1)  # Wh*Ww,Wh*Ww,nH
        return relative_position_bias.permute(2, 0, 1).contiguous()  # nH, Wh*Ww, Wh*Ww


def _mask_1d_rel_pos_index(seq_len):
    index = torch.arange(seq_len)
    return index.view(1, seq_len) - index.view(seq_len, 1) + seq_len - 1


def _add_cls_to_index_matrix(index, num_tokens, offset):
    index = index.contiguous().view(num_tokens, num_tokens)
    new_index = torch.zeros(size=(num_tokens + 1, num_tokens + 1), dtype=index.dtype)
    new_index[1:, 1:] = index
    new_index[0, 0:] = offset
    new_index[0:, 0] = offset + 1
    new_index[0, 0] = offset + 2
    return new_index


class DecoupledRelativePositionBias(nn.Module):

    def __init__(self, window_size, num_heads):
        super().__init__()
        self.window_size = window_size
        self.num_relative_distance = (2 * window_size[0] + 2, 2 * window_size[1] + 2)

        num_tokens = window_size[0] * window_size[1]

        self.relative_position_bias_for_high = nn.Parameter(torch.zeros(self.num_relative_distance[0], num_heads))
        self.relative_position_bias_for_width = nn.Parameter(torch.zeros(self.num_relative_distance[1], num_heads))
        # cls to token & token 2 cls & cls to cls

        h_index = _mask_1d_rel_pos_index(window_size[0]).view(
            window_size[0], 1, window_size[0], 1).expand(-1, window_size[1], -1, window_size[1])
        h_index = _add_cls_to_index_matrix(h_index, num_tokens, 2 * window_size[0] - 1)
        self.register_buffer("relative_position_high_index", h_index)

        w_index = _mask_1d_rel_pos_index(window_size[1]).view(
            1, window_size[1], 1, window_size[1]).expand(window_size[0], -1, window_size[0], -1)
        w_index = _add_cls_to_index_matrix(w_index, num_tokens, 2 * window_size[1] - 1)

        self.register_buffer("relative_position_width_index", w_index)

    def forward(self):
        relative_position_bias = \
            F.embedding(input=self.relative_position_high_index, weight=self.relative_position_bias_for_high) + \
            F.embedding(input=self.relative_position_width_index, weight=self.relative_position_bias_for_width)
        return relative_position_bias.permute(2, 0, 1).contiguous()


class PositionEmbeddingLearned(nn.Module):
    """
    Absolute pos embedding, learned.
    """
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.embed = nn.Embedding(in_dim, out_dim)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.uniform_(self.embed.weight)

    def forward(self, x):
        # x: (B, 5, C) or (B, mask, C) or (B, bbox+mask, C)
        n = x.size(1)
        i = torch.arange(n, device=x.device)
        pos = self.embed(i).unsqueeze(0) # (N,C) --> (1,N,C) --> (B,N,C)
        return pos


class Fast_iTPN(BaseBackbone):
    def __init__(self, img_size=224, patch_size=16, in_chans=3, embed_dim=512, depth_stage1=3, depth_stage2=3, depth=24,
                 num_heads=8, bridge_mlp_ratio=3., mlp_ratio=4., qkv_bias=True, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0.0, init_values=0.1, attn_head_dim=None, norm_layer=nn.LayerNorm,
                 patch_norm=False, num_classes=1000, use_mean_pooling=False,
                 init_scale=0.01,
                 cls_token=False,
                 grad_ckpt=False,
                 stop_grad_conv1=False,
                 use_abs_pos_emb=True,
                 use_rel_pos_bias=False,
                 use_shared_rel_pos_bias=False,
                 use_shared_decoupled_rel_pos_bias=False,
                 convmlp=False,
                 postnorm=False,
                 deepnorm=False,
                 subln=False,
                 swiglu=False,
                 naiveswiglu=False,
                 bert_dir=None,
                 **kwargs):
        super().__init__()
        self.img_size = img_size
        self.mlp_ratio = mlp_ratio
        self.grad_ckpt = grad_ckpt
        self.num_main_blocks = depth
        self.depth_stage1 = depth_stage1
        self.depth_stage2 = depth_stage2
        self.depth = depth
        self.patch_size = patch_size
        self.num_features = self.embed_dim = embed_dim
        self.convmlp = convmlp
        self.stop_grad_conv1 = stop_grad_conv1
        self.use_rel_pos_bias = use_rel_pos_bias
        self.use_shared_rel_pos_bias = use_shared_rel_pos_bias
        self.use_shared_decoupled_rel_pos_bias = use_shared_decoupled_rel_pos_bias
        self.use_decoupled_rel_pos_bias = False
        self.tokenizer = BertTokenizer.from_pretrained(bert_dir)
        self._dp_parser = None
        self._parsed_warned = False
        self.text_refine_cfg = None
        self.state_gen_cfg = None
        bert_config = BertConfig(
            vocab_size=30522,
            hidden_size=512,
            num_hidden_layers=12,
            num_attention_heads=12,
            intermediate_size=12 * 4,
            max_position_embeddings=40,
            hidden_dropout_prob=0.1,
            attention_probs_dropout_prob=0.1,
        )
        self.descript_embedding = BertEmbeddings(bert_config)
        self.descript_embedding.apply(utils.init_weights)
        self.description_patch_pos_embed = PositionEmbeddingLearned(self.embed_dim, self.embed_dim)

        mlvl_dims = {'4': embed_dim // 4, '8': embed_dim // 2, '16': embed_dim}
        # split image into non-overlapping patches
        if convmlp:
            self.patch_embed = ConvPatchEmbed(
                img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=mlvl_dims['4'],
                stop_grad_conv1=stop_grad_conv1,
                norm_layer=norm_layer if patch_norm else None)
        else:
            self.patch_embed = PatchEmbed(
                img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=mlvl_dims['4'],
                norm_layer=norm_layer if patch_norm else None)
        num_patches = self.patch_embed.num_patches

        if cls_token:
            self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        else:
            self.cls_token = None
        if use_abs_pos_emb:
            if cls_token:
                self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, embed_dim))
            else:
                self.pos_embed = nn.Parameter(torch.zeros(1, num_patches, embed_dim))
        else:
            self.pos_embed = None
        self.pos_drop = nn.Dropout(p=drop_rate)

        if use_shared_rel_pos_bias:
            self.rel_pos_bias = RelativePositionBias(window_size=self.patch_embed.patch_shape, num_heads=num_heads)
        else:
            self.rel_pos_bias = None

        if use_shared_decoupled_rel_pos_bias:
            assert self.rel_pos_bias is None
            self.rel_pos_bias = DecoupledRelativePositionBias(window_size=self.patch_embed.patch_shape,
                                                              num_heads=num_heads)

        self.subln = subln
        self.swiglu = swiglu
        self.naiveswiglu = naiveswiglu

        self.build_blocks(
            depths=[depth_stage1, depth_stage2, depth],
            dims=mlvl_dims,
            num_heads=num_heads,
            bridge_mlp_ratio=bridge_mlp_ratio,
            mlp_ratio=mlp_ratio,
            qkv_bias=qkv_bias,
            qk_scale=qk_scale,
            window_size=self.patch_embed.patch_shape if use_rel_pos_bias else None,
            drop=drop_rate,
            attn_drop=attn_drop_rate,
            drop_path_rate=drop_path_rate,
            norm_layer=norm_layer,
            init_values=init_values,
            attn_head_dim=attn_head_dim,
            postnorm=postnorm,
            deepnorm=deepnorm,
            subln=subln,
            swiglu=swiglu,
            naiveswiglu=naiveswiglu,
            convmlp=convmlp,
        )

        self.norm = nn.Identity() if use_mean_pooling else norm_layer(embed_dim)
        self.fc_norm = norm_layer(embed_dim) if use_mean_pooling else None

        if self.pos_embed is not None:
            trunc_normal_(self.pos_embed, std=.02)
        if self.cls_token is not None:
            trunc_normal_(self.cls_token, std=.02)

        self.apply(self._init_weights)

    def finetune_track(self, cfg, patch_start_index=1):
        super().finetune_track(cfg, patch_start_index=patch_start_index)
        self.state_gen_cfg = getattr(getattr(cfg, 'MODEL', None), 'STATE_GEN', None)
        self._build_text_refine_modules(getattr(self, 'text_refine_cfg', None))
        self._build_state_gen_modules(getattr(self, 'state_gen_cfg', None))

    def build_blocks(self,
                     depths=[3, 3, 24],
                     dims={'4': 128 // 4, '8': 256, '16': 512},
                     num_heads=8,
                     bridge_mlp_ratio=3.,
                     mlp_ratio=4.0,
                     qkv_bias=True,
                     qk_scale=None,
                     window_size=None,
                     drop=0.,
                     attn_drop=0.,
                     drop_path_rate=0.,
                     norm_layer=nn.LayerNorm,
                     init_values=0.,
                     attn_head_dim=None,
                     postnorm=False,
                     deepnorm=False,
                     subln=False,
                     swiglu=False,
                     naiveswiglu=False,
                     convmlp=False,
                     ):
        dpr = iter(x.item() for x in torch.linspace(0, drop_path_rate, depths[0] + depths[1] + depths[2]))

        self.blocks = nn.ModuleList()

        if convmlp:
            self.blocks.extend([
                ConvMlpBlock(
                    dim=dims['4'],
                    mlp_ratio=bridge_mlp_ratio,
                    drop_path=next(dpr),
                    norm_layer=norm_layer,
                    init_values=0.,
                    depth=depths[-1],
                    postnorm=postnorm,
                    deepnorm=deepnorm,
                    subln=subln,
                    swiglu=False,
                    naiveswiglu=False,
                ) for _ in range(depths[0])
            ])
            self.blocks.append(ConvPatchMerge(dims['4'], norm_layer))
            self.blocks.extend([
                ConvMlpBlock(
                    dim=dims['8'],
                    mlp_ratio=bridge_mlp_ratio,
                    drop_path=next(dpr),
                    norm_layer=norm_layer,
                    init_values=0.,
                    depth=depths[-1],
                    postnorm=postnorm,
                    deepnorm=deepnorm,
                    subln=subln,
                    swiglu=False,
                    naiveswiglu=False,
                ) for _ in range(depths[1])
            ])
            self.blocks.append(ConvPatchMerge(dims['8'], norm_layer))
        else:
            self.blocks.extend([
                Block(
                    dim=dims['4'],
                    num_heads=0,
                    mlp_ratio=bridge_mlp_ratio,
                    qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop,
                    attn_drop=attn_drop,
                    drop_path=next(dpr),
                    norm_layer=norm_layer,
                    init_values=init_values,
                    window_size=window_size,
                    depth=depths[-1],
                    postnorm=postnorm,
                    deepnorm=deepnorm,
                    subln=subln,
                    swiglu=swiglu,
                    naiveswiglu=naiveswiglu,
                ) for _ in range(depths[0])
            ])
            self.blocks.append(PatchMerge(dims['4'], norm_layer))
            self.blocks.extend([
                Block(
                    dim=dims['8'],
                    num_heads=0,
                    mlp_ratio=bridge_mlp_ratio,
                    qkv_bias=qkv_bias,
                    qk_scale=qk_scale,
                    drop=drop,
                    attn_drop=attn_drop,
                    drop_path=next(dpr),
                    norm_layer=norm_layer,
                    init_values=init_values,
                    window_size=window_size,
                    depth=depths[-1],
                    postnorm=postnorm,
                    deepnorm=deepnorm,
                    subln=subln,
                    swiglu=swiglu,
                    naiveswiglu=naiveswiglu,
                ) for _ in range(depths[1])
            ])
            self.blocks.append(PatchMerge(dims['8'], norm_layer))

        ######### stage 3 ########
        self.blocks.extend([
            Block(
                dim=dims['16'],
                num_heads=num_heads,
                mlp_ratio=mlp_ratio,
                qkv_bias=qkv_bias,
                qk_scale=qk_scale,
                drop=drop,
                attn_drop=attn_drop,
                drop_path=next(dpr),
                norm_layer=norm_layer,
                init_values=init_values,
                window_size=window_size,
                attn_head_dim=attn_head_dim,
                depth=depths[-1],
                postnorm=postnorm,
                deepnorm=deepnorm,
                subln=subln,
                swiglu=swiglu,
                naiveswiglu=naiveswiglu,
            ) for _ in range(depths[2])
        ])

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def get_num_layers(self):
        return len(self.blocks)

    @torch.jit.ignore
    def no_weight_decay(self):
        if self.cls_token is not None:
            return {'pos_embed', 'cls_token'}
        return {'pos_embed'}


    @torch.jit.ignore
    def no_weight_decay_keywords(self):
        return {'relative_position_bias_table'}

    def _z_feat(self,z,B):
        z = torch.stack(z, dim=1)
        _, T_z, C_z, H_z, W_z = z.shape

        z = z.flatten(0, 1)

        z = self.patch_embed(z)

        for blk in self.blocks[:-self.num_main_blocks]:
            z = blk(z)

        z = z.flatten(2).transpose(1, 2)
        z += self.pos_embed_z

        if T_z > 1:  # multiple memory frames
            z = z.view(B, T_z, -1, z.size()[-1]).contiguous()
            z = z.flatten(1, 2)

        return z

    def _x_feat(self,x):
        x = self.patch_embed(x)
        if not self.convmlp and self.stop_grad_conv1:  # self.convmlp==True
            x = x.detach() * 0.9 + x * 0.1
            assert self.convmlp == True, '想像失败'

        for blk in self.blocks[:-self.num_main_blocks]:
            x = blk(x)

        x = x.flatten(2).transpose(1, 2)
        x += self.pos_embed_x

        return x

    def _align_text_batch(self, texts, batch_size):
        if texts is None:
            return texts
        if isinstance(texts, dict):
            aligned = []
            for i in range(batch_size):
                item = {}
                for key, value in texts.items():
                    if isinstance(value, (list, tuple)):
                        if len(value) == batch_size:
                            item[key] = value[i]
                        elif len(value) == 1:
                            item[key] = value[0]
                        else:
                            item[key] = value
                    else:
                        item[key] = value
                aligned.append(item)
            return aligned
        texts = list(texts)
        if len(texts) == batch_size:
            return texts
        if len(texts) == 0:
            return [""] * batch_size
        if batch_size % len(texts) == 0:
            repeat = batch_size // len(texts)
            return [t for t in texts for _ in range(repeat)]
        raise ValueError(f"Text batch size mismatch: got {len(texts)} texts for visual batch {batch_size}")

    def _text_item_to_raw_string(self, item):
        if item is None:
            return ""
        if isinstance(item, dict):
            raw = item.get('raw', '')
            if raw is None:
                raw = ''
            return str(raw)
        return str(item)

    def _normalize_field_values(self, value):
        if value is None:
            return []
        if isinstance(value, str):
            val = value.strip()
            return [val] if val else []
        if isinstance(value, (list, tuple)):
            out = []
            for x in value:
                sx = str(x).strip()
                if sx:
                    out.append(sx)
            return out
        sval = str(value).strip()
        return [sval] if sval else []

    def _build_text_refine_modules(self, text_refine_cfg=None):
        return

    def _build_state_gen_modules(self, state_gen_cfg=None):
        return

    def _get_dp_parser(self, cac_cfg):
        if self._dp_parser is not None:
            return self._dp_parser
        if DPModel2Parser is None:
            return None
        ckpt = getattr(cac_cfg, 'DP_PARSER_CKPT', None)
        cache_dir = getattr(cac_cfg, 'DP_CACHE_DIR', None)
        if not ckpt or not cache_dir:
            return None
        use_spacy = bool(getattr(cac_cfg, 'PARSED_USE_SPACY', True))
        spacy_model = getattr(cac_cfg, 'PARSED_SPACY_MODEL', 'en_core_web_sm')
        embed_dim = int(getattr(cac_cfg, 'DP_EMBED_DIM', 300))
        hidden_dim = int(getattr(cac_cfg, 'DP_HIDDEN_DIM', 256))
        lstm_layers = int(getattr(cac_cfg, 'DP_LSTM_LAYERS', 3))
        ffnn_dim = int(getattr(cac_cfg, 'DP_FFNN_DIM', 256))
        device = str(getattr(cac_cfg, 'DP_DEVICE', 'cuda:0'))
        self._dp_parser = DPModel2Parser(
            checkpoint_path=ckpt,
            cache_dir=cache_dir,
            embed_dim=embed_dim,
            hidden_dim=hidden_dim,
            lstm_layers=lstm_layers,
            ffnn_dim=ffnn_dim,
            device=device,
            use_spacy=use_spacy,
            spacy_model=spacy_model,
        )
        return self._dp_parser

    def _build_parsed_texts(self, texts, cac_cfg):
        parser = self._get_dp_parser(cac_cfg)
        if parser is None:
            if not self._parsed_warned:
                print("[WARN] TEXT_MODE=parsed but DP parser not available; fallback to raw.")
                self._parsed_warned = True
            return texts, None

        fields = list(getattr(cac_cfg, 'PARSED_FIELDS', ['target', 'concepts', 'background']))
        join_mode = str(getattr(cac_cfg, 'PARSED_JOIN', 'sep')).lower()
        weights = getattr(cac_cfg, 'PARSED_WEIGHT', {})

        parsed_texts = []
        per_field_texts = {f: [] for f in fields}

        for t in texts:
            if isinstance(t, dict):
                out = {
                    'target': str(t.get('target', '')).strip(),
                    'concepts': self._normalize_field_values(t.get('concepts', [])),
                    'background': self._normalize_field_values(t.get('background', [])),
                }
            else:
                out = parser.extract_triplet(t)
            target = str(out.get('target', '')).strip()
            concepts = " ".join(self._normalize_field_values(out.get('concepts', [])))
            background = " ".join(self._normalize_field_values(out.get('background', [])))
            field_map = {
                'target': target,
                'concepts': concepts,
                'background': background,
            }
            parts = []
            for f in fields:
                val = field_map.get(f, '')
                if val:
                    parts.append(val)
                per_field_texts[f].append(val)

            if join_mode == 'target':
                joined = target
            elif join_mode == 'concat':
                joined = " ".join([p for p in parts if p])
            else:
                joined = " [SEP] ".join([p for p in parts if p])
            parsed_texts.append(joined)

        weight_map = {}
        if isinstance(weights, dict):
            for f in fields:
                try:
                    weight_map[f] = float(weights.get(f, 1.0))
                except Exception:
                    weight_map[f] = 1.0

        return parsed_texts, (per_field_texts, weight_map)

    def _tokenize_text(self, texts, device, max_length, add_special_tokens=True, padding='max_length'):
        tok = self.tokenizer(
            texts,
            add_special_tokens=add_special_tokens,
            truncation=True,
            padding=padding,
            max_length=max_length,
            return_tensors='pt',
            return_special_tokens_mask=True,
        )
        input_ids = tok['input_ids'].to(device=device, dtype=torch.long)
        attention_mask = tok.get('attention_mask', None)
        if attention_mask is None:
            attention_mask = input_ids.new_ones(input_ids.shape, dtype=torch.long)
        else:
            attention_mask = attention_mask.to(device)
        special_tokens_mask = tok.get('special_tokens_mask', None)
        if special_tokens_mask is None:
            special_tokens_mask = input_ids.new_zeros(input_ids.shape, dtype=torch.long)
        else:
            special_tokens_mask = special_tokens_mask.to(device)
        return input_ids, attention_mask, special_tokens_mask

    def _concat_field_tokens(self, per_field_texts, device, cac_cfg):
        fields = [str(field).lower() for field in per_field_texts.keys()]
        max_total_len = max(1, int(getattr(cac_cfg, 'MAX_TOTAL_TEXT_LEN', 16)))
        field_embeds = []
        field_masks = []
        for field in fields:
            input_ids, attention_mask, _ = self._tokenize_text(
                per_field_texts[field],
                device,
                max_length=max_total_len,
                add_special_tokens=False,
                padding='longest',
            )
            field_embeds.append(self.descript_embedding(input_ids))
            field_masks.append(attention_mask > 0)

        batch_tokens = []
        batch_masks = []
        max_used_len = 1
        batch_size = len(per_field_texts[fields[0]]) if fields else 0
        embed_dim = self.embed_dim
        base_dtype = field_embeds[0].dtype if field_embeds else self.pos_embed_x.dtype
        field_starts = {field: torch.full((batch_size,), -1, dtype=torch.long, device=device) for field in fields}
        field_ends = {field: torch.full((batch_size,), -1, dtype=torch.long, device=device) for field in fields}
        field_valids = {field: torch.zeros((batch_size,), dtype=torch.bool, device=device) for field in fields}

        for b in range(batch_size):
            pieces = []
            used_len = 0
            for field, field_embed, field_mask in zip(fields, field_embeds, field_masks):
                valid_tokens = field_embed[b][field_mask[b]]
                if valid_tokens.numel() == 0:
                    continue
                remain = max_total_len - used_len
                if remain <= 0:
                    break
                valid_tokens = valid_tokens[:remain]
                token_count = int(valid_tokens.shape[0])
                if token_count <= 0:
                    continue
                start = used_len
                end = start + token_count
                field_starts[field][b] = start
                field_ends[field][b] = end
                field_valids[field][b] = True
                pieces.append(valid_tokens)
                used_len = end
            if pieces:
                merged = torch.cat(pieces, dim=0)
                mask = torch.ones(merged.shape[0], dtype=torch.bool, device=device)
            else:
                merged = torch.zeros((1, embed_dim), device=device, dtype=base_dtype)
                mask = torch.zeros(1, dtype=torch.bool, device=device)
            max_used_len = max(max_used_len, merged.shape[0])
            batch_tokens.append(merged)
            batch_masks.append(mask)

        padded_tokens = []
        padded_masks = []
        for merged, mask in zip(batch_tokens, batch_masks):
            pad_len = max_used_len - merged.shape[0]
            if pad_len > 0:
                merged = torch.cat([merged, merged.new_zeros((pad_len, merged.shape[-1]))], dim=0)
                mask = torch.cat([mask, mask.new_zeros(pad_len)], dim=0)
            padded_tokens.append(merged)
            padded_masks.append(mask)

        l_embed = torch.stack(padded_tokens, dim=0)
        l_mask = torch.stack(padded_masks, dim=0)
        field_spans = {
            field: {
                'start': field_starts[field],
                'end': field_ends[field],
                'valid': field_valids[field],
            }
            for field in fields
        }
        return l_embed, l_mask, field_spans

    def _build_lang_vec(self, texts, device, max_length=16):
        input_ids, attention_mask, special_tokens_mask = self._tokenize_text(
            texts,
            device,
            max_length=max_length,
            add_special_tokens=True,
            padding='max_length',
        )

        l_embed = self.descript_embedding(input_ids)
        content_mask = (attention_mask > 0) & (special_tokens_mask == 0)
        content_mask_f = content_mask.to(l_embed.dtype).unsqueeze(-1)
        denom = content_mask_f.sum(dim=1).clamp(min=1.0)
        lang_vec = (l_embed * content_mask_f).sum(dim=1) / denom
        lang_valid = (content_mask_f.sum(dim=1).squeeze(-1) > 0)
        return lang_vec, lang_valid

    def _build_field_text_bank(self, per_field_texts, device, max_length):
        field_bank = {}
        for field, texts in per_field_texts.items():
            input_ids, attention_mask, special_tokens_mask = self._tokenize_text(
                texts,
                device,
                max_length=max_length,
                add_special_tokens=True,
                padding='max_length',
            )
            token_embed = self.descript_embedding(input_ids)
            token_mask = (attention_mask > 0) & (special_tokens_mask == 0)
            token_mask_f = token_mask.to(token_embed.dtype).unsqueeze(-1)
            denom = token_mask_f.sum(dim=1).clamp(min=1.0)
            field_vec = (token_embed * token_mask_f).sum(dim=1) / denom
            field_valid = (token_mask_f.sum(dim=1).squeeze(-1) > 0)
            field_bank[str(field).lower()] = {
                'tokens': token_embed,
                'mask': token_mask,
                'vec': field_vec,
                'valid': field_valid,
            }
        return field_bank

    def _l_feat(self, l, device, cac_cfg=None, parsed_meta=None, raw_texts=None):
        max_text_len = max(1, int(getattr(cac_cfg, 'MAX_TOTAL_TEXT_LEN', 16))) if cac_cfg is not None else 16
        text_mode = str(getattr(cac_cfg, 'TEXT_MODE', 'raw')).lower() if cac_cfg is not None else 'raw'
        fusion_mode = str(getattr(cac_cfg, 'TEXT_FUSION_MODE', 'single')).lower() if cac_cfg is not None else 'single'
        l_meta = None

        if parsed_meta is not None and fusion_mode == 'token_concat' and text_mode in {'parsed', 'raw_parsed'}:
            per_field_texts, _ = parsed_meta
            if text_mode == 'raw_parsed':
                concat_texts = {'raw': raw_texts if raw_texts is not None else l}
                concat_texts.update(per_field_texts)
                per_field_texts = concat_texts
            l_embed, l_mask, field_spans = self._concat_field_tokens(per_field_texts, device, cac_cfg)
            l_meta = {'field_spans': field_spans}
        else:
            input_ids, attention_mask, _ = self._tokenize_text(
                l,
                device,
                max_length=max_text_len,
                add_special_tokens=True,
                padding='max_length',
            )
            l_embed = self.descript_embedding(input_ids)
            l_mask = attention_mask > 0

        lang_vec, lang_valid = self._build_lang_vec(l, device, max_length=max_text_len)
        l = l_embed + self.description_patch_pos_embed(l_embed)
        return l, l_mask, lang_vec, lang_valid, l_meta

    def _build_search_bg_mask(self, search_tok, search_anno):
        if search_tok is None or search_anno is None:
            return None
        lens_x = int(search_tok.shape[1])
        grid = int(math.sqrt(lens_x))
        if grid * grid != lens_x:
            return None
        cx = (torch.arange(grid, device=search_tok.device, dtype=search_tok.dtype) + 0.5) / grid
        cy = (torch.arange(grid, device=search_tok.device, dtype=search_tok.dtype) + 0.5) / grid
        yy, xx = torch.meshgrid(cy, cx)
        centers = torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=-1)

        x1y1wh = search_anno.to(search_tok.device).to(search_tok.dtype)
        x1_raw = x1y1wh[:, 0:1]
        y1_raw = x1y1wh[:, 1:2]
        w_raw = x1y1wh[:, 2:3].clamp(min=0.0)
        h_raw = x1y1wh[:, 3:4].clamp(min=0.0)
        x2_raw = x1_raw + w_raw
        y2_raw = y1_raw + h_raw

        x1 = x1_raw.clamp(0.0, 1.0)
        y1 = y1_raw.clamp(0.0, 1.0)
        x2 = torch.maximum(x2_raw.clamp(0.0, 1.0), x1)
        y2 = torch.maximum(y2_raw.clamp(0.0, 1.0), y1)

        cxv = centers[:, 0].view(1, -1)
        cyv = centers[:, 1].view(1, -1)
        obj = (cxv >= x1) & (cxv <= x2) & (cyv >= y1) & (cyv <= y2)
        return (~obj).to(search_tok.dtype)

    def _merge_field_vecs(self, parsed_vecs, weight_map=None, fallback_vec=None, fallback_valid=None):
        if not parsed_vecs:
            return fallback_vec, fallback_valid
        field_vecs = []
        field_weights = []
        weight_map = weight_map or {}
        for field, item in parsed_vecs.items():
            if field.startswith('_'):
                continue
            if item is None:
                continue
            vec, valid = item
            weight = float(weight_map.get(field, 1.0)) if isinstance(weight_map, dict) else 1.0
            if weight <= 0.0:
                continue
            field_vecs.append(vec)
            field_weights.append(weight * valid.to(vec.dtype))
        if not field_vecs:
            return fallback_vec, fallback_valid
        stacked = torch.stack(field_vecs, dim=0)
        weights = torch.stack(field_weights, dim=0).unsqueeze(-1)
        denom = weights.sum(dim=0).clamp(min=1e-6)
        merged_vec = (stacked * weights).sum(dim=0) / denom
        merged_valid = (denom.squeeze(-1) > 0)
        return merged_vec, merged_valid

    def _apply_field_span_deltas(self, l_feat, l_mask, field_spans, base_parsed_vecs, refined_parsed_vecs, fields=None):
        if (
            l_feat is None
            or l_mask is None
            or field_spans is None
            or base_parsed_vecs is None
            or refined_parsed_vecs is None
        ):
            return l_feat, None
        if fields is None:
            fields = ['concepts']
        if not isinstance(fields, (list, tuple)):
            fields = [fields]

        pos = torch.arange(l_feat.shape[1], device=l_feat.device, dtype=torch.long).view(1, -1)
        updated = l_feat
        debug_stats = {}
        l_mask_bool = l_mask.to(torch.bool)

        for field in fields:
            field_key = str(field).lower()
            span_entry = field_spans.get(field_key, None)
            base_item = base_parsed_vecs.get(field_key, None) if base_parsed_vecs is not None else None
            refined_item = refined_parsed_vecs.get(field_key, None) if refined_parsed_vecs is not None else None
            if span_entry is None or base_item is None or refined_item is None:
                continue

            start = span_entry.get('start', None)
            end = span_entry.get('end', None)
            span_valid = span_entry.get('valid', None)
            if start is None or end is None or span_valid is None:
                continue

            base_vec, base_valid = base_item
            refined_vec, refined_valid = refined_item
            valid = span_valid.to(torch.bool)
            if base_valid is not None:
                valid = valid & base_valid.to(torch.bool)
            if refined_valid is not None:
                valid = valid & refined_valid.to(torch.bool)
            if not valid.any().item():
                continue

            field_mask = (pos >= start.unsqueeze(1)) & (pos < end.unsqueeze(1))
            field_mask = field_mask & valid.unsqueeze(1) & l_mask_bool
            if not field_mask.any().item():
                continue

            delta = (refined_vec - base_vec).unsqueeze(1)
            updated = updated + delta * field_mask.to(updated.dtype).unsqueeze(-1)
            debug_stats[f'{field_key}_tokens'] = float(field_mask.to(torch.float32).sum(dim=1).mean().detach().cpu())
            debug_stats[f'{field_key}_delta_mean'] = float((refined_vec - base_vec).abs().mean().detach().cpu())
            debug_stats[f'{field_key}_valid_ratio'] = float(valid.to(torch.float32).mean().detach().cpu())
            debug_stats[f'{field_key}_start0'] = float(start[0].detach().cpu())
            debug_stats[f'{field_key}_end0'] = float(end[0].detach().cpu())

        return updated, (debug_stats if debug_stats else None)

    def _build_target_support(self, parsed_vecs, search_tokens, text_refine_cfg=None, score_mode='cosine', eps=1e-6):
        cfg = text_refine_cfg if text_refine_cfg is not None else getattr(self, 'text_refine_cfg', None)
        if cfg is None or not bool(getattr(cfg, 'TARGET_CONDITION_ENABLE', False)):
            return None, None
        if parsed_vecs is None or search_tokens is None:
            return None, None
        target_item = parsed_vecs.get('target', None)
        if target_item is None:
            return None, None
        target_vec, target_valid = target_item
        if target_vec is None:
            return None, None

        if score_mode == 'cosine':
            search_tokens_norm = F.normalize(search_tokens, dim=-1, eps=eps)
            target_vec_norm = F.normalize(target_vec, dim=-1, eps=eps)
            support_logits = torch.matmul(search_tokens_norm, target_vec_norm.unsqueeze(-1)).squeeze(-1)
        else:
            support_logits = torch.matmul(search_tokens, target_vec.unsqueeze(-1)).squeeze(-1) / math.sqrt(search_tokens.shape[-1])

        topk = int(getattr(cfg, 'TARGET_SUPPORT_TOPK', 0))
        act = str(getattr(cfg, 'TARGET_SUPPORT_ACT', 'softmax')).lower()
        support_weights = None
        if act == 'relu':
            support_weights = F.relu(support_logits)
            if topk > 0 and topk < support_weights.shape[1]:
                top_idx = torch.topk(support_weights, k=topk, dim=1).indices
                keep = torch.zeros_like(support_weights)
                keep.scatter_(1, top_idx, 1.0)
                support_weights = support_weights * keep
            denom = support_weights.sum(dim=1, keepdim=True).clamp(min=1e-6)
            support_weights = support_weights / denom
        else:
            if topk > 0 and topk < support_logits.shape[1]:
                top_idx = torch.topk(support_logits, k=topk, dim=1).indices
                keep_mask = torch.zeros_like(support_logits, dtype=torch.bool)
                keep_mask.scatter_(1, top_idx, True)
                support_logits = support_logits.masked_fill(~keep_mask, -1e4)
            tau = float(getattr(cfg, 'TARGET_SUPPORT_TAU', 0.07))
            support_weights = torch.softmax(support_logits / max(tau, 1e-6), dim=1)

        if target_valid is not None:
            support_weights = support_weights * target_valid.to(support_weights.dtype).unsqueeze(1)
            denom = support_weights.sum(dim=1, keepdim=True).clamp(min=1e-6)
            support_weights = support_weights / denom

        debug_stats = {
            'target_support_max': float(support_weights.max(dim=1).values.mean().detach().cpu()),
            'target_support_valid_ratio': float((target_valid.to(torch.float32).mean().detach().cpu()) if target_valid is not None else 1.0),
        }
        return support_weights, debug_stats

    def _compute_vec_support(self, field_vec, field_valid, search_tokens, score_mode='cosine', target_support=None, eps=1e-6):
        if field_vec is None or search_tokens is None:
            return None, None
        if score_mode == 'cosine':
            search_tokens_norm = F.normalize(search_tokens, dim=-1, eps=eps)
            field_vec_norm = F.normalize(field_vec, dim=-1, eps=eps)
            support_logits = torch.matmul(search_tokens_norm, field_vec_norm.unsqueeze(-1)).squeeze(-1)
        else:
            support_logits = torch.matmul(search_tokens, field_vec.unsqueeze(-1)).squeeze(-1) / math.sqrt(search_tokens.shape[-1])

        if target_support is not None:
            support_score = (support_logits * target_support).sum(dim=1)
        else:
            support_score = support_logits.max(dim=1).values

        if field_valid is not None:
            valid_mask = field_valid.to(torch.bool)
            support_score = torch.where(valid_mask, support_score, torch.full_like(support_score, -1.0))
        return support_score, support_logits

    def _score_to_unit_interval(self, score_tensor):
        if score_tensor is None:
            return None
        return torch.sigmoid(score_tensor)

    def _field_state_scale(self, field_key, state_name, cfg):
        weak_scale = float(getattr(cfg, 'WEAK_SCALE', 0.35))
        off_scale = float(getattr(cfg, 'OFF_SCALE', 0.0))
        if field_key == 'background':
            if state_name == 'active':
                return 1.0
            if state_name == 'weak':
                return weak_scale
            return off_scale
        if state_name == 'strong':
            return 1.0
        if state_name == 'weak':
            return weak_scale
        return off_scale

    def _resolve_field_state(self, field_key, field_score, field_valid, cfg):
        valid = True
        if field_valid is not None:
            valid = bool(field_valid.item())
        if not valid:
            return ('off' if field_key != 'background' else 'off'), 0

        if field_key == 'background':
            active_th = float(getattr(cfg, 'BACKGROUND_ACTIVE_TH', 0.60))
            weak_th = float(getattr(cfg, 'BACKGROUND_WEAK_TH', 0.40))
            if field_score >= active_th:
                return 'active', 2
            if field_score >= weak_th:
                return 'weak', 1
            return 'off', 0

        strong_th = float(getattr(cfg, 'CONCEPT_STRONG_TH', 0.65))
        weak_th = float(getattr(cfg, 'CONCEPT_WEAK_TH', 0.45))
        if field_score >= strong_th:
            return 'strong', 2
        if field_score >= weak_th:
            return 'weak', 1
        return 'off', 0

    def _apply_state_to_parsed_vecs(self, parsed_vecs, field_scales):
        if parsed_vecs is None or field_scales is None:
            return parsed_vecs
        updated_vecs = dict(parsed_vecs)
        for field_key, scale in field_scales.items():
            item = updated_vecs.get(field_key, None)
            if item is None or scale is None:
                continue
            vec, valid = item
            scale = scale.to(vec.device, dtype=vec.dtype)
            new_vec = vec * scale.unsqueeze(-1)
            if valid is not None:
                keep_mask = scale > 0.0
                new_valid = valid.to(torch.bool) & keep_mask.to(torch.bool)
            else:
                new_valid = None
            updated_vecs[field_key] = (new_vec, new_valid)
        return updated_vecs

    def _apply_field_span_scales(self, l_feat, l_mask, field_spans, field_scales):
        if l_feat is None or l_mask is None or field_spans is None or field_scales is None:
            return l_feat, None
        pos = torch.arange(l_feat.shape[1], device=l_feat.device, dtype=torch.long).view(1, -1)
        updated = l_feat
        debug_stats = {}
        l_mask_bool = l_mask.to(torch.bool)

        for field_key, scale in field_scales.items():
            span_entry = field_spans.get(field_key, None)
            if span_entry is None or scale is None:
                continue
            start = span_entry.get('start', None)
            end = span_entry.get('end', None)
            span_valid = span_entry.get('valid', None)
            if start is None or end is None or span_valid is None:
                continue
            valid = span_valid.to(torch.bool)
            field_mask = (pos >= start.unsqueeze(1)) & (pos < end.unsqueeze(1))
            field_mask = field_mask & valid.unsqueeze(1) & l_mask_bool
            if not field_mask.any().item():
                continue

            scale_map = torch.ones_like(field_mask, dtype=updated.dtype)
            field_scale = scale.to(updated.device, dtype=updated.dtype).unsqueeze(1).expand_as(scale_map)
            scale_map = torch.where(field_mask, field_scale, scale_map)
            updated = updated * scale_map.unsqueeze(-1)
            debug_stats[f'{field_key}_scale_mean'] = float(scale.to(torch.float32).mean().detach().cpu())
            debug_stats[f'{field_key}_scaled_tokens'] = float(field_mask.to(torch.float32).sum(dim=1).mean().detach().cpu())

        return updated, (debug_stats if debug_stats else None)

    def _run_state_generator(
        self,
        parsed_vecs,
        base_parsed_vecs,
        per_field_texts,
        search_tokens,
        l_feat,
        l_mask,
        field_spans,
        weight_map,
        fallback_lang_vec,
        fallback_lang_valid,
        enable_cac=False,
        state_gen_cfg=None,
    ):
        cfg = state_gen_cfg if state_gen_cfg is not None else getattr(self, 'state_gen_cfg', None)
        if (
            cfg is None
            or not bool(getattr(cfg, 'ENABLE', False))
            or parsed_vecs is None
            or per_field_texts is None
            or search_tokens is None
        ):
            return parsed_vecs, fallback_lang_vec, fallback_lang_valid, l_feat, None

        score_mode = 'cosine'
        text_refine_cfg = getattr(self, 'text_refine_cfg', None)
        if text_refine_cfg is not None:
            score_mode = str(getattr(text_refine_cfg, 'TOKEN_SCORE', 'cosine')).lower()
        eps = 1e-6
        target_condition_enable = bool(getattr(cfg, 'TARGET_CONDITION_ENABLE', False))
        target_support = None
        if target_condition_enable:
            target_support, _ = self._build_target_support(
                parsed_vecs,
                search_tokens,
                text_refine_cfg=cfg,
                score_mode=score_mode,
                eps=eps,
            )

        target_item = parsed_vecs.get('target', None)
        target_score_raw = None
        if target_item is not None:
            target_score_raw, _ = self._compute_vec_support(
                target_item[0],
                target_item[1],
                search_tokens,
                score_mode=score_mode,
                target_support=None,
                eps=eps,
            )
        target_score = self._score_to_unit_interval(target_score_raw)
        if target_score is None:
            target_score = torch.zeros(search_tokens.shape[0], device=search_tokens.device, dtype=search_tokens.dtype)

        target_condition_fields = getattr(cfg, 'TARGET_CONDITION_FIELDS', ['concepts'])
        if not isinstance(target_condition_fields, (list, tuple)):
            target_condition_fields = [target_condition_fields]
        target_condition_fields = {str(field).lower() for field in target_condition_fields}
        field_specs = {
            'concepts': ('concept', target_condition_enable and 'concepts' in target_condition_fields),
            'background': ('background', target_condition_enable and 'background' in target_condition_fields),
        }
        field_scores = {}
        field_labels = {}
        field_ids = {}
        field_scales = {}
        state_dicts = []
        state_texts = []
        state_jsons = []
        trigger_mode = str(getattr(cfg, 'TRIGGER_MODE', 'low_conf_only')).lower()
        low_conf_th = float(getattr(cfg, 'LOW_CONF_TH', 0.45))
        batch_size = search_tokens.shape[0]

        for field_key, (slot_name, target_conditioned) in field_specs.items():
            item = parsed_vecs.get(field_key, None)
            if item is None:
                field_scores[field_key] = torch.zeros(batch_size, device=search_tokens.device, dtype=search_tokens.dtype)
                field_labels[field_key] = ['off'] * batch_size
                field_ids[field_key] = torch.zeros(batch_size, device=search_tokens.device, dtype=search_tokens.dtype)
                field_scales[field_key] = torch.zeros(batch_size, device=search_tokens.device, dtype=search_tokens.dtype)
                continue

            raw_score, _ = self._compute_vec_support(
                item[0],
                item[1],
                search_tokens,
                score_mode=score_mode,
                target_support=target_support if target_conditioned else None,
                eps=eps,
            )
            score = self._score_to_unit_interval(raw_score)
            if score is None:
                score = torch.zeros(batch_size, device=search_tokens.device, dtype=search_tokens.dtype)
            field_scores[field_key] = score

            label_list = []
            id_list = []
            scale_list = []
            valid_tensor = item[1] if item[1] is not None else torch.ones(batch_size, device=search_tokens.device, dtype=torch.bool)
            for idx in range(batch_size):
                label, state_id = self._resolve_field_state(
                    slot_name,
                    float(score[idx].detach().cpu()),
                    valid_tensor[idx:idx + 1],
                    cfg,
                )
                label_list.append(label)
                id_list.append(float(state_id))
                scale_list.append(float(self._field_state_scale(slot_name, label, cfg)))
            field_labels[field_key] = label_list
            field_ids[field_key] = torch.tensor(id_list, device=search_tokens.device, dtype=search_tokens.dtype)
            field_scales[field_key] = torch.tensor(scale_list, device=search_tokens.device, dtype=search_tokens.dtype)

        state_confidence = torch.maximum(field_scores.get('concepts', target_score), field_scores.get('background', target_score))
        if trigger_mode in {'always', 'all_frames'}:
            triggered = torch.ones(batch_size, device=search_tokens.device, dtype=torch.bool)
        elif trigger_mode == 'low_conf_only':
            triggered = state_confidence < low_conf_th
        else:
            triggered = torch.ones(batch_size, device=search_tokens.device, dtype=torch.bool)

        applied_field_scales = {}
        concept_policy = str(getattr(cfg, 'CONCEPT_POLICY', 'update')).lower()
        background_policy = str(getattr(cfg, 'BACKGROUND_POLICY', 'update')).lower()
        if concept_policy == 'update':
            applied_field_scales['concepts'] = torch.where(
                triggered,
                field_scales['concepts'],
                torch.ones_like(field_scales['concepts']),
            )
        if background_policy == 'update':
            applied_field_scales['background'] = torch.where(
                triggered,
                field_scales['background'],
                torch.ones_like(field_scales['background']),
            )

        allow_apply_with_cac = bool(getattr(cfg, 'APPLY_WITH_CAC', False))
        allow_state_apply = not enable_cac or allow_apply_with_cac
        adjusted_vecs = parsed_vecs
        adjusted_l_feat = l_feat
        span_scale_debug = None
        update_text_mode = str(getattr(cfg, 'UPDATE_TEXT_MODE', 'constrained_state')).lower()
        text_apply_mode = str(getattr(cfg, 'TEXT_APPLY_MODE', 'prune_and_keep')).lower()
        if allow_state_apply and update_text_mode == 'constrained_state' and text_apply_mode == 'prune_and_keep':
            adjusted_vecs = self._apply_state_to_parsed_vecs(parsed_vecs, applied_field_scales)
            adjusted_l_feat, span_scale_debug = self._apply_field_span_scales(
                l_feat,
                l_mask,
                field_spans,
                applied_field_scales,
            )

        adjusted_lang_vec, adjusted_lang_valid = self._merge_field_vecs(
            adjusted_vecs,
            weight_map=weight_map,
            fallback_vec=fallback_lang_vec,
            fallback_valid=fallback_lang_valid,
        )
        if adjusted_lang_vec is None:
            adjusted_lang_vec = fallback_lang_vec
            adjusted_lang_valid = fallback_lang_valid

        concept_base = base_parsed_vecs.get('concepts', None) if base_parsed_vecs is not None else None
        background_base = base_parsed_vecs.get('background', None) if base_parsed_vecs is not None else None
        concept_delta = torch.zeros(batch_size, device=search_tokens.device, dtype=search_tokens.dtype)
        background_delta = torch.zeros_like(concept_delta)
        if concept_base is not None and parsed_vecs.get('concepts', None) is not None:
            concept_delta = (parsed_vecs['concepts'][0] - concept_base[0]).abs().mean(dim=1)
        if background_base is not None and parsed_vecs.get('background', None) is not None:
            background_delta = (parsed_vecs['background'][0] - background_base[0]).abs().mean(dim=1)

        state_feat = torch.stack(
            [
                target_score,
                field_scores['concepts'],
                field_scores['background'],
                concept_delta,
                background_delta,
                triggered.to(search_tokens.dtype),
                field_ids['concepts'] / 2.0,
                field_ids['background'] / 2.0,
            ],
            dim=1,
        )

        target_state_name = 'keep' if str(getattr(cfg, 'TARGET_POLICY', 'freeze')).lower() == 'freeze' else 'dynamic'
        output_text_enable = bool(getattr(cfg, 'OUTPUT_TEXT_ENABLE', True))
        output_format = str(getattr(cfg, 'OUTPUT_FORMAT', 'json')).lower()
        target_texts = per_field_texts.get('target', [''] * batch_size)
        concept_texts = per_field_texts.get('concepts', [''] * batch_size)
        background_texts = per_field_texts.get('background', [''] * batch_size)
        for idx in range(batch_size):
            target_text = str(target_texts[idx]).strip()
            concept_text = str(concept_texts[idx]).strip()
            background_text = str(background_texts[idx]).strip()
            state_dict = {
                'target': target_text,
                'target_state': target_state_name,
                'concept': concept_text,
                'concept_state': field_labels['concepts'][idx],
                'background': background_text,
                'background_state': field_labels['background'][idx],
                'triggered': bool(triggered[idx].item()),
            }
            state_dicts.append(state_dict)
            if output_text_enable and output_format == 'json':
                state_jsons.append(json.dumps(state_dict, ensure_ascii=True))
            if output_text_enable and output_format in {'json', 'slot_text', 'text'}:
                state_texts.append(
                    "target: {} [{}]; concept: {} [{}]; background: {} [{}]".format(
                        target_text if target_text else '-',
                        target_state_name,
                        concept_text if concept_text else '-',
                        field_labels['concepts'][idx],
                        background_text if background_text else '-',
                        field_labels['background'][idx],
                    )
                )

        debug_info = {
            'triggered': triggered,
            'trigger_ratio': float(triggered.to(torch.float32).mean().detach().cpu()),
            'target_score': target_score.detach(),
            'concept_score': field_scores['concepts'].detach(),
            'background_score': field_scores['background'].detach(),
            'concept_state': field_labels['concepts'],
            'background_state': field_labels['background'],
            'state_applied': bool(allow_state_apply and update_text_mode == 'constrained_state' and text_apply_mode == 'prune_and_keep'),
            'state_dicts': state_dicts,
            'state_json': state_jsons if output_text_enable and output_format == 'json' else None,
            'state_text': state_texts if output_text_enable and output_format in {'json', 'slot_text', 'text'} else None,
            'state_feat': state_feat.detach() if bool(getattr(cfg, 'OUTPUT_FEAT_ENABLE', True)) else None,
        }
        if span_scale_debug is not None:
            debug_info.update({f'span_scale_{k}': v for k, v in span_scale_debug.items()})

        return adjusted_vecs, adjusted_lang_vec, adjusted_lang_valid, adjusted_l_feat, debug_info

    def _refine_parsed_vecs(self, parsed_vecs, parsed_field_bank, search_tok, search_anno=None, text_refine_cfg=None):
        cfg = text_refine_cfg if text_refine_cfg is not None else getattr(self, 'text_refine_cfg', None)
        if (
            parsed_vecs is None
            or parsed_field_bank is None
            or search_tok is None
            or cfg is None
            or not bool(getattr(cfg, 'ENABLE', False))
        ):
            return parsed_vecs, None
        if str(getattr(cfg, 'MODE', 'token_reweight')).lower() != 'token_reweight':
            return parsed_vecs, None
        output_mode = str(getattr(cfg, 'OUTPUT_MODE', 'vec')).lower()
        if output_mode not in {'vec', 'field_span'}:
            return parsed_vecs, None

        del search_anno
        search_tokens = search_tok.detach() if bool(getattr(cfg, 'DETACH_SEARCH', False)) else search_tok
        score_mode = str(getattr(cfg, 'TOKEN_SCORE', 'cosine')).lower()
        weight_act = str(getattr(cfg, 'TOKEN_WEIGHT_ACT', 'softmax')).lower()
        debug_enabled = bool(getattr(cfg, 'DEBUG', False))
        eps = 1e-6

        refined_vecs = dict(parsed_vecs)
        apply_to = getattr(cfg, 'APPLY_TO', ['concepts', 'background'])
        if not isinstance(apply_to, (list, tuple)):
            apply_to = [apply_to]
        target_condition_fields = getattr(cfg, 'TARGET_CONDITION_FIELDS', ['concepts'])
        if not isinstance(target_condition_fields, (list, tuple)):
            target_condition_fields = [target_condition_fields]
        target_condition_fields = [str(f).lower() for f in target_condition_fields]
        target_support, target_support_debug = self._build_target_support(
            parsed_vecs,
            search_tokens,
            text_refine_cfg=cfg,
            score_mode=score_mode,
            eps=eps,
        )
        debug_stats = {}
        if debug_enabled and target_support_debug is not None:
            debug_stats.update(target_support_debug)
        for field in apply_to:
            field_key = str(field).lower()
            if field_key not in refined_vecs:
                continue
            field_entry = parsed_field_bank.get(field_key, None)
            if field_entry is None:
                continue
            field_tokens = field_entry['tokens']
            field_mask = field_entry['mask']
            field_valid = field_entry['valid']
            if bool(getattr(cfg, 'DETACH_FIELD', False)):
                field_tokens = field_tokens.detach()

            if score_mode == 'cosine':
                field_tokens_norm = F.normalize(field_tokens, dim=-1, eps=eps)
                search_tokens_norm = F.normalize(search_tokens, dim=-1, eps=eps)
                sim = torch.matmul(field_tokens_norm, search_tokens_norm.transpose(1, 2))
            else:
                sim = torch.matmul(field_tokens, search_tokens.transpose(1, 2)) / math.sqrt(field_tokens.shape[-1])

            use_target_condition = (
                target_support is not None
                and bool(getattr(cfg, 'TARGET_CONDITION_ENABLE', False))
                and field_key in target_condition_fields
            )
            if use_target_condition:
                search_support = (sim * target_support.unsqueeze(1)).sum(dim=-1)
            else:
                search_support = sim.max(dim=-1).values
            search_support = search_support.masked_fill(~field_mask, float('-inf'))

            if weight_act == 'sigmoid':
                token_weights = torch.sigmoid(search_support)
                token_weights = token_weights * field_mask.to(token_weights.dtype)
                denom = token_weights.sum(dim=1, keepdim=True).clamp(min=1.0)
                token_weights = token_weights / denom
            else:
                safe_support = torch.where(
                    field_mask,
                    search_support,
                    torch.full_like(search_support, -1e4),
                )
                token_weights = torch.softmax(safe_support, dim=1)
                token_weights = token_weights * field_mask.to(token_weights.dtype)
                denom = token_weights.sum(dim=1, keepdim=True).clamp(min=eps)
                token_weights = token_weights / denom

            refined = (field_tokens * token_weights.unsqueeze(-1)).sum(dim=1)
            if field_valid is not None:
                valid_mask = field_valid.to(refined.dtype).unsqueeze(-1)
                fallback_vec = field_entry['vec']
                refined = valid_mask * refined + (1.0 - valid_mask) * fallback_vec
            refined_vecs[field_key] = (refined, field_valid)
            if debug_enabled:
                debug_stats[field_key] = float(token_weights.max(dim=1).values.mean().detach().cpu())
                if use_target_condition:
                    debug_stats[f'{field_key}_target_conditioned'] = 1.0
        return refined_vecs, (debug_stats if debug_stats else None)

    def _get_cac_layer_indices(self, cac_cfg, total_layers=None):
        if cac_cfg is None:
            return []
        raw_indices = getattr(cac_cfg, 'LAYER_INDICES', [])
        if raw_indices is None:
            return []
        if not isinstance(raw_indices, (list, tuple)):
            raw_indices = [raw_indices]
        out = []
        for idx in raw_indices:
            try:
                idx_int = int(idx)
            except Exception:
                continue
            if total_layers is not None:
                if idx_int < 1 or idx_int > total_layers:
                    continue
            elif idx_int < 1:
                continue
            out.append(idx_int)
        return sorted(set(out))

    def _get_cac_apply_count(self, cac_cfg, total_layers=None):
        if cac_cfg is None or not getattr(cac_cfg, 'ENABLE', False):
            return 0
        layer_indices = self._get_cac_layer_indices(cac_cfg, total_layers=total_layers)
        if layer_indices:
            return len(layer_indices)
        apply_n = int(getattr(cac_cfg, 'APPLY_N', 0))
        if apply_n > 0:
            return apply_n
        return int(getattr(cac_cfg, 'APPLY_LAST_N', 0))

    def _is_cac_layer(self, layer_idx, total_layers, cac_cfg):
        layer_indices = self._get_cac_layer_indices(cac_cfg, total_layers=total_layers)
        if layer_indices:
            return (layer_idx + 1) in layer_indices
        apply_n = self._get_cac_apply_count(cac_cfg, total_layers=total_layers)
        if apply_n <= 0:
            return False
        apply_n = min(apply_n, total_layers)
        policy = str(getattr(cac_cfg, 'LAYER_POLICY', 'last')).lower()
        if policy == 'first':
            return layer_idx < apply_n
        return layer_idx >= (total_layers - apply_n)

    def _fusion_feat(self, z, x, l, l_mask, B, temporal_query, cac_ctx=None):
        if self.add_cls_token:
            temporal_init = self.temporal_token.expand(B, 1, -1)
            temporal_init = temporal_init + self.temporal_pos_embed

        z_mask = torch.ones((B, z.shape[1]), dtype=torch.bool, device=z.device)
        x_mask = torch.ones((B, x.shape[1]), dtype=torch.bool, device=x.device)
        attn_mask = torch.cat([l_mask.to(torch.bool), z_mask, x_mask], dim=1)

        x = combine_tokens(z, x, mode=self.cat_mode)
        x = combine_tokens(l, x, mode=self.cat_mode)

        if self.add_cls_token:
            if temporal_query is None:
                temporal_tokens = temporal_init
            else:
                temporal_tokens = temporal_query

            x = torch.cat([temporal_tokens, x], dim=1)
            temporal_mask = torch.ones(
                (B, temporal_tokens.shape[1]),
                dtype=torch.bool,
                device=x.device
            )
            attn_mask = torch.cat([temporal_mask, attn_mask], dim=1)
            if cac_ctx is not None:
              cac_ctx['temporal_len'] = temporal_tokens.shape[1]

        x = self.pos_drop(x)

        rel_pos_bias = self.rel_pos_bias() if self.rel_pos_bias is not None else None
        assert rel_pos_bias == None, 'rel_pos_bias not None'
        assert self.grad_ckpt == False, 'grad_ckpt != Fasle'
        cac_cfg = getattr(self, 'cac_cfg', None)
        enable_cac = self._get_cac_apply_count(cac_cfg, total_layers=self.num_main_blocks) > 0 and cac_ctx is not None
        main_blocks = self.blocks[-self.num_main_blocks:]
        for i, blk in enumerate(main_blocks):
            is_cac_layer = enable_cac and self._is_cac_layer(i, len(main_blocks), cac_cfg)
            x, attn = blk(x, attn_mask=attn_mask, cac_ctx=cac_ctx, cac_layer=is_cac_layer)

        x = self.norm(x)

        return x,attn

    def _split_feat(self,attn,topk):
        #fusion_feat(bs,temporal_l + descript_l + z_l + x_l)
        lens_x = self.pos_embed_x.shape[1]
        attn = torch.mean(attn,dim=1)
        # x = fusion_feat[:, -lens_x:]
        l2s = attn[:,topk,-lens_x:]
        max,index = torch.sort(l2s,dim=1,descending=True)
        top_index = index[:,:topk]

        return top_index,l2s

    def _finder(self,x,index):
        index_expanded = index.unsqueeze(2)
        result = torch.gather(x, 1, index_expanded.expand(-1, -1, 512))
        return result


    def forward_features(self, z, x, l, temporal_query=None, top_K=None, search_anno=None):
        B = x.shape[0]
        raw_text_items = self._align_text_batch(l, B)
        raw_text = [self._text_item_to_raw_string(item) for item in raw_text_items]
        z_feat = self._z_feat(z,B)
        x_feat = self._x_feat(x)
        l_text = raw_text
        parsed_meta = None
        cac_cfg = getattr(self, 'cac_cfg', None)
        text_mode = str(getattr(cac_cfg, 'TEXT_MODE', 'raw')).lower() if cac_cfg is not None else 'raw'

        if text_mode == 'empty':
            l_text = [""] * B
        elif text_mode == 'parsed':
            l_text, parsed_meta = self._build_parsed_texts(raw_text_items, cac_cfg)
        elif text_mode == 'raw_parsed':
            parsed_text, parsed_meta = self._build_parsed_texts(raw_text_items, cac_cfg)
            l_text = []
            for raw_item, parsed_item in zip(raw_text, parsed_text):
                parts = [str(raw_item).strip(), str(parsed_item).strip()]
                l_text.append(" [SEP] ".join([p for p in parts if p]))

        l_feat, l_mask, lang_vec, lang_valid, l_meta = self._l_feat(
            l_text,
            x_feat.device,
            cac_cfg=cac_cfg,
            parsed_meta=parsed_meta,
            raw_texts=raw_text,
        )
        parsed_vecs = None
        parsed_field_bank = None
        text_refine_debug = None
        state_gen_debug = None
        weight_map = None
        refined_lang_vec = None
        refined_lang_valid = None
        field_spans = l_meta.get('field_spans', None) if l_meta is not None else None
        base_parsed_vecs = None
        enable_cac = (
            cac_cfg is not None
            and getattr(cac_cfg, 'ENABLE', False)
            and self._get_cac_apply_count(cac_cfg) > 0
        )
        if parsed_meta is not None:
            per_field_texts, weight_map = parsed_meta
            max_text_len = max(1, int(getattr(cac_cfg, 'MAX_TOTAL_TEXT_LEN', 16)))
            parsed_field_bank = self._build_field_text_bank(
                per_field_texts,
                x_feat.device,
                max_length=max_text_len,
            )
            parsed_vecs = {
                f: (item['vec'], item['valid']) for f, item in parsed_field_bank.items()
            }
            base_parsed_vecs = dict(parsed_vecs)
            merged_lang_vec, merged_lang_valid = self._merge_field_vecs(
                parsed_vecs,
                weight_map=weight_map,
                fallback_vec=lang_vec,
                fallback_valid=lang_valid,
            )
            if merged_lang_vec is not None:
                base_lang_vec = merged_lang_vec
                lang_vec = merged_lang_vec
                lang_valid = merged_lang_valid
            else:
                base_lang_vec = lang_vec

            text_refine_cfg = getattr(self, 'text_refine_cfg', None)
            parsed_vecs, text_refine_debug = self._refine_parsed_vecs(
                parsed_vecs,
                parsed_field_bank,
                x_feat,
                search_anno=search_anno,
                text_refine_cfg=text_refine_cfg,
            )
            refined_lang_vec, refined_lang_valid = self._merge_field_vecs(
                parsed_vecs,
                weight_map=weight_map,
                fallback_vec=lang_vec,
                fallback_valid=lang_valid,
            )
            if refined_lang_vec is not None:
                lang_vec = refined_lang_vec
                lang_valid = refined_lang_valid
                if not enable_cac:
                    writeback_mode = str(getattr(text_refine_cfg, 'WRITEBACK_MODE', 'global')).lower() if text_refine_cfg is not None else 'global'
                    if writeback_mode == 'field_span':
                        writeback_fields = getattr(text_refine_cfg, 'WRITEBACK_FIELDS', ['concepts']) if text_refine_cfg is not None else ['concepts']
                        l_feat, span_writeback_debug = self._apply_field_span_deltas(
                            l_feat,
                            l_mask,
                            field_spans,
                            base_parsed_vecs,
                            parsed_vecs,
                            fields=writeback_fields,
                        )
                        if span_writeback_debug is not None:
                            if text_refine_debug is None:
                                text_refine_debug = {}
                            text_refine_debug.update({f'writeback_{k}': v for k, v in span_writeback_debug.items()})
                    else:
                        lang_delta = (refined_lang_vec - base_lang_vec).unsqueeze(1)
                        l_feat = l_feat + lang_delta * l_mask.to(l_feat.dtype).unsqueeze(-1)

            parsed_vecs, state_lang_vec, state_lang_valid, l_feat, state_gen_debug = self._run_state_generator(
                parsed_vecs,
                base_parsed_vecs,
                per_field_texts,
                x_feat,
                l_feat,
                l_mask,
                field_spans,
                weight_map,
                fallback_lang_vec=lang_vec,
                fallback_lang_valid=lang_valid,
                enable_cac=enable_cac,
                state_gen_cfg=getattr(self, 'state_gen_cfg', None),
            )
            if state_lang_vec is not None:
                lang_vec = state_lang_vec
                lang_valid = state_lang_valid

        cac_ctx = None
        if enable_cac and search_anno is not None:
            bg_mask = self._build_search_bg_mask(x_feat, search_anno)
            if bg_mask is not None:
                cac_ctx = {
                    'bg_mask': bg_mask,
                    'lens_x': int(x_feat.shape[1]),
                    'cfg': cac_cfg,
                }
                if getattr(cac_cfg, 'LANG_ENABLE', False):
                    if getattr(cac_cfg, 'LANG_DETACH_VEC', False):
                        lang_vec = lang_vec.detach()
                    cac_ctx['lang_vec'] = lang_vec
                    cac_ctx['lang_valid'] = lang_valid
                if parsed_vecs is not None:
                    cac_ctx['parsed_vecs'] = parsed_vecs

        fusion_feat,attn = self._fusion_feat(z_feat, x_feat, l_feat, l_mask, B, temporal_query, cac_ctx=cac_ctx)  #attn(bs,head_num,l,l)
        top_index,att_l2s = self._split_feat(attn,top_K)
        l2s = self._finder(x_feat,top_index)
        aux_dict = {"attn": attn,
                    "attn_l2s": att_l2s,
                    "temproal_token": l2s}

        if cac_ctx is not None and getattr(cac_cfg, 'DEBUG', False):
            aux_dict['cac_delta_mean'] = cac_ctx.get('debug_last_delta_mean', 0.0)
            aux_dict['cac_delta_bg_mean'] = cac_ctx.get('debug_last_delta_bg_mean', 0.0)
            aux_dict['cac_lang_valid_ratio'] = float(lang_valid.to(torch.float32).mean().detach().cpu())
        if text_refine_debug is not None:
            for key, value in text_refine_debug.items():
                aux_dict[f'text_refine_{key}_max_weight'] = value
        if state_gen_debug is not None:
            aux_dict['state_triggered'] = state_gen_debug.get('triggered', None)
            aux_dict['state_trigger_ratio'] = state_gen_debug.get('trigger_ratio', 0.0)
            aux_dict['state_concept_score'] = state_gen_debug.get('concept_score', None)
            aux_dict['state_background_score'] = state_gen_debug.get('background_score', None)
            aux_dict['state_concept_state'] = state_gen_debug.get('concept_state', None)
            aux_dict['state_background_state'] = state_gen_debug.get('background_state', None)
            aux_dict['state_applied'] = state_gen_debug.get('state_applied', False)
            if state_gen_debug.get('state_text', None) is not None:
                aux_dict['state_text'] = state_gen_debug.get('state_text', None)
            if state_gen_debug.get('state_json', None) is not None:
                aux_dict['state_json'] = state_gen_debug.get('state_json', None)
            if state_gen_debug.get('state_feat', None) is not None:
                aux_dict['state_feat'] = state_gen_debug.get('state_feat', None)
            for key, value in state_gen_debug.items():
                if key.startswith('span_scale_'):
                    aux_dict[f'state_{key}'] = value

        return fusion_feat, aux_dict

    def forward(self, z, x, l, temporal_query, top_K, search_anno=None, **kwargs):
        """
        Joint feature extraction and relation modeling for the basic ViT backbone.
        Args:
            z (torch.Tensor): template feature, [B, C, H_z, W_z]
            x (torch.Tensor): search region feature, [B, C, H_x, W_x]
            l (list.str): descript of search refion

        Returns:
            x (torch.Tensor): merged template and search region feature, [B, L_z+L_x, C]
            attn : None
        """
        x, aux_dict = self.forward_features(z, x, l, temporal_query, top_K, search_anno=search_anno)

        return x, aux_dict


@register_model
def fast_itpn_tiny_1112_patch16_224(pretrained=False, **kwargs):
    model = Fast_iTPN(
        patch_size=16, embed_dim=384, depth_stage1=1, depth_stage2=1, depth=12, num_heads=6, bridge_mlp_ratio=3.,
        mlp_ratio=3., qkv_bias=True, norm_layer=partial(nn.LayerNorm, eps=1e-6),
        convmlp=True,
        naiveswiglu=True,
        subln=True,
        **kwargs)
    model.default_cfg = _cfg()
    if pretrained:
        checkpoint = torch.load(
            kwargs["init_ckpt"], map_location="cpu"
        )
        model.load_state_dict(checkpoint["model"])
    return model


@register_model
def fast_itpn_small_2220_patch16_224(pretrained=False, **kwargs):
    model = Fast_iTPN(
        patch_size=16, embed_dim=384, depth_stage1=2, depth_stage2=2, depth=20, num_heads=6, bridge_mlp_ratio=3.,
        mlp_ratio=3., qkv_bias=True, norm_layer=partial(nn.LayerNorm, eps=1e-6),
        convmlp=True,
        naiveswiglu=True,
        subln=True,
        **kwargs)
    model.default_cfg = _cfg()
    if pretrained:
        checkpoint = torch.load(
            kwargs["init_ckpt"], map_location="cpu"
        )
        model.load_state_dict(checkpoint["model"])
    return model


@register_model
def fast_itpn_base_3324_patch16_224(pretrained=False,bert_dir=None, **kwargs ):
    model = Fast_iTPN(
        patch_size=16, embed_dim=512, depth_stage1=3, depth_stage2=3, depth=24, num_heads=8, bridge_mlp_ratio=3.,
        mlp_ratio=3., qkv_bias=True, norm_layer=partial(nn.LayerNorm, eps=1e-6),
        convmlp=True,
        naiveswiglu=True,
        subln=True,
        bert_dir=bert_dir,
        **kwargs)
    model.default_cfg = _cfg()

    if pretrained:
            checkpoint = torch.load(pretrained, weights_only=False,map_location="cpu")
            #print(checkpoint.keys())
            missing_keys, unexpected_keys = model.load_state_dict(checkpoint['net'], strict=False)
            print(missing_keys, unexpected_keys)
            print('Load pretrained model from: ' + pretrained)

    return model


@register_model
def fast_itpn_large_2240_patch16_256(pretrained=False, **kwargs):
    model = Fast_iTPN(
        patch_size=16, embed_dim=768, depth_stage1=2, depth_stage2=2, depth=40, num_heads=12, bridge_mlp_ratio=3.,
        mlp_ratio=3., qkv_bias=True, norm_layer=partial(nn.LayerNorm, eps=1e-6),
        convmlp=True,
        naiveswiglu=True,
        subln=True,
        **kwargs)
    model.default_cfg = _cfg()
    if pretrained:
        checkpoint = torch.load(
            kwargs["init_ckpt"], map_location="cpu"
        )
        model.load_state_dict(checkpoint["model"])
    return model

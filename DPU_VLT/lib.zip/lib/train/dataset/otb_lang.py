import os
import random
import json
import torch
import numpy as np
import pandas
from collections import OrderedDict

from .base_video_dataset import BaseVideoDataset
from lib.train.data import jpeg4py_loader_w_failsafe
from lib.utils.string_utils import clean_string


class OTB99Lang(BaseVideoDataset):
    """OTB99-Lang dataset with local train/test split support."""

    def __init__(self, root=None, image_loader=jpeg4py_loader_w_failsafe, split='train',
                 data_fraction=None, parsed_text_path=''):
        self.root = root
        self.split = split
        super().__init__('otb99lang', root, image_loader)

        self.img_root = os.path.join(self.root, 'OTB_videos')
        self.query_root = os.path.join(self.root, f'OTB_query_{split}')
        self.sequence_list = self._build_sequence_list()
        self.parsed_text_path = parsed_text_path
        self.parsed_text_cache = self._load_parsed_text_cache(parsed_text_path)

        if data_fraction is not None:
            self.sequence_list = random.sample(self.sequence_list, int(len(self.sequence_list) * data_fraction))

    def get_name(self):
        return 'otb99lang'

    def _build_sequence_list(self):
        if not os.path.isdir(self.query_root):
            raise FileNotFoundError(f'OTB99-Lang query split not found: {self.query_root}')
        seq_names = []
        for file_name in sorted(os.listdir(self.query_root)):
            if not file_name.endswith('.txt'):
                continue
            seq_name = os.path.splitext(file_name)[0]
            seq_root = os.path.join(self.img_root, seq_name)
            if not os.path.isdir(seq_root):
                raise FileNotFoundError(f'OTB99-Lang sequence folder not found for {seq_name}: {seq_root}')
            seq_names.append(seq_name)
        return seq_names

    def _load_parsed_text_cache(self, parsed_text_path):
        if not parsed_text_path:
            return {}
        if not os.path.isfile(parsed_text_path):
            print(f"[WARN] OTB99-Lang parsed text cache not found: {parsed_text_path}")
            return {}
        try:
            with open(parsed_text_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                print(f"[INFO] Loaded OTB99-Lang parsed text cache from {parsed_text_path} ({len(data)} entries)")
                return data
        except Exception as e:
            print(f"[WARN] Failed to load OTB99-Lang parsed text cache {parsed_text_path}: {e}")
        return {}

    def has_class_info(self):
        return True

    def has_occlusion_info(self):
        return True

    def get_num_sequences(self):
        return len(self.sequence_list)

    def _get_sequence_path(self, seq_id):
        return os.path.join(self.img_root, self.sequence_list[seq_id])

    def _get_sequence_name(self, seq_id):
        return self.sequence_list[seq_id]

    def _read_bb_anno(self, seq_path):
        gt_path = os.path.join(seq_path, 'groundtruth_rect.txt')
        with open(gt_path, 'r') as f:
            first_line = f.readline()
        sep = ',' if ',' in first_line else r'\s+'
        gt = pandas.read_csv(gt_path, delimiter=sep, header=None, dtype=np.float32, na_filter=False,
                             engine='python').values
        return torch.tensor(gt)

    def get_sequence_info(self, seq_id):
        seq_path = self._get_sequence_path(seq_id)
        bbox = self._read_bb_anno(seq_path)
        valid = (bbox[:, 2] > 0) & (bbox[:, 3] > 0)
        visible = valid.byte()
        return {'bbox': bbox, 'valid': valid, 'visible': visible}

    def _get_frame_path(self, seq_path, frame_id):
        return os.path.join(seq_path, 'img', f'{frame_id + 1:04d}.jpg')

    def _get_frame(self, seq_path, frame_id):
        return self.image_loader(self._get_frame_path(seq_path, frame_id))

    def _read_raw_language(self, seq_id):
        seq_name = self.sequence_list[seq_id]
        txt_path = os.path.join(self.query_root, seq_name + '.txt')
        if not os.path.isfile(txt_path):
            return ""
        with open(txt_path, 'r', encoding='utf-8') as f:
            return clean_string(f.read().strip())

    def _build_raw_nlp_dict(self, raw_text):
        raw_text = str(raw_text).strip()
        return {
            'raw': raw_text,
            'target': '',
            'concepts': '',
            'background': '',
        }

    def _get_cached_nlp(self, seq_id):
        if not self.parsed_text_cache:
            return None
        seq_name = self.sequence_list[seq_id]
        item = self.parsed_text_cache.get(seq_name, None)
        if not isinstance(item, dict):
            return None
        return {
            'raw': str(item.get('raw', '')),
            'target': str(item.get('target', '')),
            'concepts': " ".join(str(x) for x in item.get('concepts', [])) if isinstance(item.get('concepts', []), list) else str(item.get('concepts', '')),
            'background': " ".join(str(x) for x in item.get('background', [])) if isinstance(item.get('background', []), list) else str(item.get('background', '')),
        }

    def get_language_description(self, seq_id):
        parsed = self._get_cached_nlp(seq_id)
        if parsed is not None:
            return parsed
        raw = self._read_raw_language(seq_id)
        return self._build_raw_nlp_dict(raw)

    def get_class_name(self, seq_id):
        return self.sequence_list[seq_id]

    def get_frames(self, seq_id, frame_ids, anno=None):
        seq_path = self._get_sequence_path(seq_id)
        seq_name = self._get_sequence_name(seq_id)

        frame_list = [self._get_frame(seq_path, f_id) for f_id in frame_ids]

        if anno is None:
            anno = self.get_sequence_info(seq_id)

        anno_frames = {}
        for key, value in anno.items():
            anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]

        language_dict = self.get_language_description(seq_id)
        language_dict_list = [language_dict for _ in frame_ids]

        object_meta = OrderedDict({
            'object_class_name': seq_name,
            'motion_class': None,
            'major_class': None,
            'root_class': None,
            'motion_adverb': None,
            'language_description': language_dict_list
        })

        return frame_list, anno_frames, object_meta

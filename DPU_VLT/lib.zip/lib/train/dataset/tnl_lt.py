import os
import os.path
import torch
import numpy as np
import pandas
import csv
import json
import random
import bisect
from collections import OrderedDict
from .base_video_dataset import BaseVideoDataset
from lib.train.data import jpeg4py_loader,opencv_loader
from lib.train.admin import env_settings

class TNLLT(BaseVideoDataset):
    def __init__(self, root=None, image_loader=opencv_loader, split="train", data_fraction=None, parsed_text_path='', qwen_cache_enable=False, qwen_cache_path='', qwen_cache_use_prob=1.0, qwen_cache_max_gap=-1, qwen_cache_debug=False, qwen_cache_debug_interval=200):
        """
        args:
            root - path to the lasot dataset.
            image_loader  -  
            split - If split='train', the official train split (protocol-II) is used for training. Note: Only one of
                    vid_ids or split option can be used at a time.
            data_fraction - Fraction of dataset to be used. The complete dataset is used by default
        """        
        root = env_settings().tnllt_dir if root is None else root
        super().__init__('TNLLT', root, image_loader)

        # Keep a list of all classes
        # self.class_list = [f for f in os.listdir(self.root)]
        # self.class_to_id = {cls_name: cls_id for cls_id, cls_name in enumerate(self.class_list)}

        self.split = split
        self.sequence_list = self._build_sequence_list(split)
        self.parsed_text_path = parsed_text_path
        self.parsed_text_cache = self._load_parsed_text_cache(parsed_text_path)

        self.qwen_cache_enable = bool(qwen_cache_enable)
        self.qwen_cache_path = qwen_cache_path
        self.qwen_cache_use_prob = float(qwen_cache_use_prob)
        self.qwen_cache_max_gap = int(qwen_cache_max_gap)
        self.qwen_cache_by_seq = self._load_qwen_cache(qwen_cache_path) if self.qwen_cache_enable else {}
        self.qwen_cache_debug = bool(qwen_cache_debug)
        self.qwen_cache_debug_interval = max(1, int(qwen_cache_debug_interval))
        self.qwen_cache_debug_stats = {
            'calls': 0,
            'used': 0,
            'fallback_prob': 0,
            'fallback_no_seq': 0,
            'fallback_no_prev': 0,
            'fallback_gap': 0,
        }

        if data_fraction is not None:
            self.sequence_list = random.sample(self.sequence_list, int(len(self.sequence_list)*data_fraction))

        # self.seq_per_class = self._build_class_list()        

    def _build_sequence_list(self, split=None):
        if split is not None:
            ltr_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
            if split == 'train':
                file_path = os.path.join(ltr_path, 'data_specs', 'tnl_lt_train_split.txt')
            elif split == 'val':
                file_path = os.path.join(ltr_path, 'data_specs', 'tnl_lt_val_split.txt')
            elif split == 'test':
                file_path = os.path.join(ltr_path, 'data_specs', 'tnl_lt_test_split.txt')
            else :
                raise ValueError('Unknown split name.')
            sequence_list = pandas.read_csv(file_path, header=None).squeeze("columns").values.tolist()
        else:
            raise ValueError('split is none')

        return sequence_list

    def _load_parsed_text_cache(self, parsed_text_path):
        if not parsed_text_path:
            return {}
        if not os.path.isfile(parsed_text_path):
            print(f"[WARN] TNLLT parsed text cache not found: {parsed_text_path}")
            return {}
        try:
            with open(parsed_text_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                print(f"[INFO] Loaded TNLLT parsed text cache from {parsed_text_path} ({len(data)} entries)")
                return data
        except Exception as e:
            print(f"[WARN] Failed to load TNLLT parsed text cache {parsed_text_path}: {e}")
        return {}

    def _load_qwen_cache(self, qwen_cache_path):
        if not qwen_cache_path:
            return {}
        if not os.path.isfile(qwen_cache_path):
            print(f"[WARN] TNLLT Qwen cache not found: {qwen_cache_path}")
            return {}
        try:
            with open(qwen_cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f"[WARN] Failed to load TNLLT Qwen cache {qwen_cache_path}: {e}")
            return {}

        entries = data.get('entries', {}) if isinstance(data, dict) else {}
        if not isinstance(entries, dict):
            print(f"[WARN] TNLLT Qwen cache malformed (entries is not dict): {qwen_cache_path}")
            return {}

        by_seq = {}
        for key, item in entries.items():
            if not isinstance(item, dict):
                continue
            seq_name = str(item.get('seq_name', '')).strip()
            if not seq_name:
                if isinstance(key, str) and ':' in key:
                    seq_name = key.rsplit(':', 1)[0]
                else:
                    continue
            frame_id = item.get('frame_id', None)
            if frame_id is None:
                if isinstance(key, str) and ':' in key:
                    try:
                        frame_id = int(key.rsplit(':', 1)[1])
                    except Exception:
                        continue
                else:
                    continue
            try:
                frame_id = int(frame_id)
            except Exception:
                continue

            by_seq.setdefault(seq_name, []).append((
                frame_id,
                {
                    'concepts': str(item.get('qwen_concept', '')).strip(),
                    'background': str(item.get('qwen_background', '')).strip(),
                }
            ))

        for seq_name in by_seq.keys():
            by_seq[seq_name].sort(key=lambda x: x[0])

        total = sum(len(v) for v in by_seq.values())
        print(f"[INFO] Loaded TNLLT Qwen cache from {qwen_cache_path} ({len(by_seq)} seqs, {total} frame entries)")
        return by_seq

    def _clone_lang_dict(self, lang_dict):
        return {
            'raw': str(lang_dict.get('raw', '')),
            'target': str(lang_dict.get('target', '')),
            'concepts': str(lang_dict.get('concepts', '')),
            'background': str(lang_dict.get('background', '')),
        }

    def _get_qwen_refined_nlp(self, seq_id, frame_id, base_lang):
        if not self.qwen_cache_enable:
            return base_lang
        if not isinstance(base_lang, dict):
            return base_lang

        stats = self.qwen_cache_debug_stats
        stats['calls'] += 1

        if self.qwen_cache_use_prob < 1.0 and random.random() > self.qwen_cache_use_prob:
            stats['fallback_prob'] += 1
            if self.qwen_cache_debug and stats['calls'] % self.qwen_cache_debug_interval == 0:
                self._log_qwen_cache_debug()
            return base_lang

        seq_name = self.sequence_list[seq_id]
        seq_entries = self.qwen_cache_by_seq.get(seq_name, None)
        if not seq_entries:
            stats['fallback_no_seq'] += 1
            if self.qwen_cache_debug and stats['calls'] % self.qwen_cache_debug_interval == 0:
                self._log_qwen_cache_debug()
            return base_lang

        frame_ids = [it[0] for it in seq_entries]
        pos = bisect.bisect_right(frame_ids, int(frame_id)) - 1
        if pos < 0:
            stats['fallback_no_prev'] += 1
            if self.qwen_cache_debug and stats['calls'] % self.qwen_cache_debug_interval == 0:
                self._log_qwen_cache_debug()
            return base_lang

        anchor_frame, refined = seq_entries[pos]
        if self.qwen_cache_max_gap >= 0 and (int(frame_id) - anchor_frame) > self.qwen_cache_max_gap:
            stats['fallback_gap'] += 1
            if self.qwen_cache_debug and stats['calls'] % self.qwen_cache_debug_interval == 0:
                self._log_qwen_cache_debug()
            return base_lang

        updated = self._clone_lang_dict(base_lang)
        if isinstance(refined, dict):
            concept = str(refined.get('concepts', '')).strip()
            background = str(refined.get('background', '')).strip()
            if concept != '':
                updated['concepts'] = concept
            if background != '':
                updated['background'] = background
        stats['used'] += 1
        if self.qwen_cache_debug and stats['calls'] % self.qwen_cache_debug_interval == 0:
            self._log_qwen_cache_debug()
        return updated

    def _log_qwen_cache_debug(self):
        if not self.qwen_cache_debug:
            return
        stats = self.qwen_cache_debug_stats
        calls = int(stats.get('calls', 0))
        if calls <= 0:
            return
        used = int(stats.get('used', 0))
        fallback_prob = int(stats.get('fallback_prob', 0))
        fallback_no_seq = int(stats.get('fallback_no_seq', 0))
        fallback_no_prev = int(stats.get('fallback_no_prev', 0))
        fallback_gap = int(stats.get('fallback_gap', 0))
        print(
            f"[TNLLT-QWEN] calls={calls} used={used} used_ratio={used / max(calls, 1):.3f} "
            f"fallback_prob={fallback_prob} fallback_no_seq={fallback_no_seq} "
            f"fallback_no_prev={fallback_no_prev} fallback_gap={fallback_gap}"
        )

    def _get_cached_nlp(self, seq_id):
        if not self.parsed_text_cache:
            return None
        seq_name = self.sequence_list[seq_id]
        parsed = self.parsed_text_cache.get(seq_name, None)
        if not isinstance(parsed, dict):
            return None
        return {
            'raw': str(parsed.get('raw', '')),
            'target': str(parsed.get('target', '')),
            'concepts': " ".join(str(x) for x in parsed.get('concepts', [])),
            'background': " ".join(str(x) for x in parsed.get('background', [])),
        }
    
    def _read_target_visible(self, seq_path):
        target_visible = self.read_absent_label(seq_path)
        return target_visible
    
    def read_bb_anno(self, seq_path):
        bb_anno_file = os.path.join(seq_path, "groundtruth.txt")
        gt = pandas.read_csv(bb_anno_file, delimiter=',', header=None, dtype=np.float32, na_filter=False, low_memory=False).values
        return torch.tensor(gt)
    
    def read_absent_label(self,seq_path):
        abs_label_file = os.path.join(seq_path, "absent_label.txt")
        absent_label = pandas.read_csv(abs_label_file, delimiter=',', header=None, dtype=np.int32, na_filter=False, low_memory=False).values
        # 移除所有维度为1的维度
        return torch.tensor(absent_label).squeeze()
    
    def read_attributes(self,seq_path):
        attributes_file = os.path.join(seq_path, "attributes.txt")
        attributes_label = pandas.read_csv(attributes_file, delimiter=',', header=None, dtype=np.int32, na_filter=False, low_memory=False).values
        # 移除所有维度为1的维度
        return torch.tensor(attributes_label).squeeze()

    def get_nlp(self,seq_id):
        cached = self._get_cached_nlp(seq_id)
        if cached is not None:
            return cached

        seq_path = self._get_sequence_path(seq_id)
        nlp_file_path = os.path.join(seq_path, 'language.txt')
        
        if os.path.exists(nlp_file_path):
            with open(nlp_file_path, 'r', encoding='utf-8') as file:
                npl_text = file.read()
            return npl_text
        else:
            raise FileNotFoundError(f"No nlp.txt file found at {nlp_file_path}")

    def _get_sequence_path(self, seq_id):
        seq_name = self.sequence_list[seq_id]
        return os.path.join(self.root, seq_name)
    
    def get_sequence_info(self, seq_id):
        """ Returns information about a particular sequences,

        args:
            seq_id - index of the sequence

        returns:
            Dict
            """
        seq_path = self._get_sequence_path(seq_id)
        bbox = self.read_bb_anno(seq_path)
        absent_label = self.read_absent_label(seq_path)
        attributes_label = self.read_attributes(seq_path)
        lan = self.get_nlp(seq_id)

        # 检查宽高是否都大于0
        valid = (bbox[:, 2] > 0) & (bbox[:, 3] > 0)
        # visible = self._read_target_visible(seq_path) & valid.byte()
        visible = self._read_target_visible(seq_path)

        return {'bbox':bbox,'absent_label':absent_label,'attributes_label':attributes_label,'language':lan,'nlp':lan,'visible':visible ,'valid':valid}

    def get_name(self):
        return 'tnllt'

    # TODO: 下面几个短的函数考证一下，默认has_class_info为false
    def has_class_info(self):
        return False

    def has_occlusion_info(self):
        return False

    def get_num_sequences(self):
        return len(self.sequence_list)

    def _get_frame_path(self, seq_path, frame_id):
        return os.path.join(seq_path, 'imgs', '{:05}.png'.format(frame_id+1))  
    
    def _get_frame(self, seq_path, frame_id):
        return self.image_loader(self._get_frame_path(seq_path, frame_id))
    
    def get_frames(self, seq_id, frame_ids, anno=None):
        """ Get a set of frames from a particular sequence

        args:
            seq_id      - index of sequence
            frame_ids   - a list of frame numbers
            anno(None)  - The annotation for the sequence (see get_sequence_info). If None, they will be loaded.

        returns:
            list - List of frames corresponding to frame_ids
            list - List of dicts for each frame
            dict - A dict containing meta information about the sequence, e.g. class of the target object.

        """
        seq_path = self._get_sequence_path(seq_id)
        frame_list = [self._get_frame(seq_path, f_id) for f_id in frame_ids]
        if anno is None:
            anno = self.get_sequence_info(seq_id)

        base_lang = anno.get('language', None)
        language_dict_list = []
        for f_id in frame_ids:
            if isinstance(base_lang, dict):
                language_dict_list.append(self._get_qwen_refined_nlp(seq_id, f_id, base_lang))
            else:
                language_dict_list.append(base_lang)

        anno_frames = {}
        for key, value in anno.items():
            try:
                if key == 'language' or key == 'nlp':
                    anno_frames[key] = language_dict_list
                elif key == 'attributes_label':
                    anno_frames[key] = [value] * len(frame_ids)
                else:
                    anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]
            except TypeError as e:
                print(f"Error processing key {key}: {e}")
                anno_frames[key] = [None] * len(frame_ids)
        object_meta = OrderedDict({'motion_class': None,
                                   'major_class': None,
                                   'root_class': None,
                                   'motion_adverb': None,
                                   'language_description': language_dict_list})
        return frame_list, anno_frames, object_meta

    def get_path(self, seq_id, frame_ids):
        seq_path = self._get_sequence_path(seq_id)
        frame_list = [self._get_frame_path(seq_path, f_id) for f_id in frame_ids]
        return frame_list


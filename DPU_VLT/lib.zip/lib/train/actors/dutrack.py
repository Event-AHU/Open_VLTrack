from . import BaseActor
from lib.utils.misc import NestedTensor, interpolate
from lib.utils.box_ops import box_cxcywh_to_xyxy, box_xywh_to_xyxy
import torch
from lib.utils.merge import merge_template_search
from ...utils.heapmap_utils import generate_heatmap
from ...utils.ce_utils import generate_mask_cond, adjust_keep_rate
import random
import string
import json
import os



class DUTrackActor(BaseActor):
    """ Actor for training ODTrack models """

    def __init__(self, net, objective, loss_weight, settings, cfg=None):
        super().__init__(net, objective)
        self.loss_weight = loss_weight
        self.settings = settings
        self.bs = self.settings.batchsize  # batch size
        self.cfg = cfg
        self._synonym_dict = None
        try:
            syn_path = getattr(self.cfg.TRAIN.TEXT_AUG, 'SYNONYM_PATH', '') if hasattr(self.cfg, 'TRAIN') else ''
            if isinstance(syn_path, str) and len(syn_path) > 0 and os.path.isfile(syn_path):
                with open(syn_path, 'r', encoding='utf-8') as f:
                    self._synonym_dict = json.load(f)
        except Exception:
            self._synonym_dict = None

    def __call__(self, data):
        """
        args:
            data - The input data, should contain the fields 'template', 'search', 'gt_bbox'.
            template_images: (N_t, batch, 3, H, W)
            search_images: (N_s, batch, 3, H, W)
        returns:
            loss    - the training loss
            status  -  dict containing detailed losses
        """
        # forward pass
        out_dict = self.forward_pass(data)

        # compute losses
        loss, status = self.compute_losses(out_dict, data)

        return loss, status

    def forward_pass(self, data):
        template_list = []
        search_list = []

        for i in range(self.settings.num_template):
            template_img_i = data['template_images'][i].view(-1, *data['template_images'].shape[2:])  # (batch, 3, 128, 128)
            template_list.append(template_img_i)

        for i in range(self.settings.num_search):
            search_img_i = data['search_images'][i].view(-1, *data['search_images'].shape[2:])  # (batch, 3, 320, 320)
            search_list.append(search_img_i)
            
        box_mask_z = []
        ce_keep_rate = None
        if self.cfg.MODEL.BACKBONE.CE_LOC:
            for i in range(self.settings.num_template):
                box_mask_z.append(generate_mask_cond(self.cfg, template_list[i].shape[0], template_list[i].device,
                                                    data['template_anno'][i]))
            box_mask_z = torch.cat(box_mask_z, dim=1)

            ce_start_epoch = self.cfg.TRAIN.CE_START_EPOCH
            ce_warm_epoch = self.cfg.TRAIN.CE_WARM_EPOCH
            ce_keep_rate = adjust_keep_rate(data['epoch'], warmup_epochs=ce_start_epoch,
                                                total_epochs=ce_start_epoch + ce_warm_epoch,
                                                ITERS_PER_EPOCH=1,
                                                base_keep_rate=self.cfg.MODEL.BACKBONE.CE_KEEP_RATIO[0])



        descript = data.get('language_description')
        if descript is None:
            descript = [[''] for _ in range(self.settings.num_search)]

        if getattr(self.cfg.TRAIN, 'TEXT_AUG', None) and self.cfg.TRAIN.TEXT_AUG.ENABLE:
            def _perturb_sentence(sent: str):
                if not isinstance(sent, str) or len(sent) == 0:
                    return sent
                s = sent
                # 同义词替换（按词表）：
                if self._synonym_dict and random.random() < self.cfg.TRAIN.TEXT_AUG.SYNONYM_PROB:
                    toks = s.split()
                    if len(toks) > 0:
                        idx = random.randrange(len(toks))
                        key = toks[idx].lower()
                        cand = self._synonym_dict.get(key)
                        if isinstance(cand, list) and len(cand) > 0:
                            rep = random.choice(cand)
                            # 保持原词大小写风格（首字母大写）
                            if toks[idx][:1].isupper():
                                rep = rep[:1].upper() + rep[1:]
                            toks[idx] = rep
                            s = ' '.join(toks)
                if random.random() < self.cfg.TRAIN.TEXT_AUG.DROP_PROB:
                    toks = s.split()
                    if len(toks) > 1:
                        drop_idx = random.randrange(len(toks))
                        toks.pop(drop_idx)
                        s = ' '.join(toks)
                if random.random() < self.cfg.TRAIN.TEXT_AUG.SHUFFLE_PROB:
                    toks = s.split()
                    if len(toks) > 2:
                        i = random.randrange(len(toks)-1)
                        toks[i], toks[i+1] = toks[i+1], toks[i]
                        s = ' '.join(toks)
                if random.random() < self.cfg.TRAIN.TEXT_AUG.CHAR_NOISE_PROB:
                    if len(s) > 1:
                        op = random.choice(['replace','insert','delete'])
                        pos = random.randrange(len(s))
                        if op == 'replace':
                            s = s[:pos] + random.choice(string.ascii_letters) + s[pos+1:]
                        elif op == 'insert':
                            s = s[:pos] + random.choice(string.ascii_letters) + s[pos:]
                        else:
                            s = s[:pos] + s[pos+1:]
                if random.random() < self.cfg.TRAIN.TEXT_AUG.CASE_PERTURB_PROB:
                    s = ''.join(c.upper() if random.random()<0.5 else c.lower() for c in s)
                if random.random() < self.cfg.TRAIN.TEXT_AUG.PUNCT_PERTURB_PROB:
                    s = s.replace(',', '')
                    if random.random()<0.5:
                        s = s + random.choice(['.', '!', '?'])
                return s

            perturbed = []
            for i in range(len(descript)):
                if isinstance(descript[i], (list, tuple)):
                    perturbed.append([_perturb_sentence(x) for x in descript[i]])
                else:
                    perturbed.append([_perturb_sentence(str(descript[i]))])
            descript = perturbed
        # 把训练数据里 search 帧对应的 GT bbox（search_anno）从dataloader/processor 透传进模型，让 backbone 在 forward 时能用 bbox 构造简易D（背景原型）并计算 δ，从而在注意力 logits 上加 CAC bias。
        out_dict = self.net(template=template_list,
                            search=search_list,
                            descript=descript,
                            search_anno=data.get('search_anno'),
                            )

        return out_dict

    def compute_losses(self, pred_dict, gt_dict, return_status=True):
        # currently only support the type of pred_dict is list
        assert isinstance(pred_dict, list)
        loss_dict = {}
        total_status = {}
        total_loss = torch.tensor(0., dtype=torch.float).cuda() # 定义 0 tensor，并指定GPU设备
        
        # generate gt gaussian map
        gt_gaussian_maps_list = generate_heatmap(gt_dict['search_anno'], self.cfg.DATA.SEARCH.SIZE, self.cfg.MODEL.BACKBONE.STRIDE)
        
        for i in range(len(pred_dict)):
            # get GT
            gt_bbox = gt_dict['search_anno'][i]  # (Ns, batch, 4) (x1,y1,w,h) -> (batch, 4)
            gt_gaussian_maps = gt_gaussian_maps_list[i].unsqueeze(1)

            # Get boxes
            pred_boxes = pred_dict[i]['pred_boxes']
            if torch.isnan(pred_boxes).any():
                raise ValueError("Network outputs is NAN! Stop Training")
            num_queries = pred_boxes.size(1)
            pred_boxes_vec = box_cxcywh_to_xyxy(pred_boxes).view(-1, 4)  # (B,N,4) --> (BN,4) (x1,y1,x2,y2)
            gt_boxes_vec = box_xywh_to_xyxy(gt_bbox)[:, None, :].repeat((1, num_queries, 1)).view(-1, 4).clamp(min=0.0, max=1.0)
            # (B,4) --> (B,1,4) --> (B,N,4)
            
            # compute giou and iou
            try:
                giou_loss, iou = self.objective['giou'](pred_boxes_vec, gt_boxes_vec)  # (BN,4) (BN,4)
            except:
                giou_loss, iou = torch.tensor(0.0).cuda(), torch.tensor(0.0).cuda()
            loss_dict['giou'] = giou_loss
            
            # compute l1 loss
            l1_loss = self.objective['l1'](pred_boxes_vec, gt_boxes_vec)  # (BN,4) (BN,4)
            loss_dict['l1'] = l1_loss
            
            # compute location loss
            if 'score_map' in pred_dict[i]:
                location_loss = self.objective['focal'](pred_dict[i]['score_map'], gt_gaussian_maps)
            else:
                location_loss = torch.tensor(0.0, device=l1_loss.device)
            loss_dict['focal'] = location_loss
                
            # weighted sum
            loss = sum(loss_dict[k] * self.loss_weight[k] for k in loss_dict.keys() if k in self.loss_weight)
            total_loss += loss
            
            if return_status:
                # status for log
                status = {}
                
                mean_iou = iou.detach().mean()
                status = {f"{i}frame_Loss/total": loss.item(),
                        f"{i}frame_Loss/giou": giou_loss.item(),
                        f"{i}frame_Loss/l1": l1_loss.item(),
                        f"{i}frame_Loss/location": location_loss.item(),
                        f"{i}frame_IoU": mean_iou.item()}

                # Optional CAC debug stats (paper-first sanity checks)
                if 'cac_delta_mean' in pred_dict[i]:
                    status[f"{i}frame_CAC/delta_mean"] = float(pred_dict[i]['cac_delta_mean'])
                if 'cac_delta_bg_mean' in pred_dict[i]:
                    status[f"{i}frame_CAC/delta_bg_mean"] = float(pred_dict[i]['cac_delta_bg_mean'])
                    
                total_status.update(status)

        if return_status:
            return total_loss, total_status
        else:
            return total_loss
